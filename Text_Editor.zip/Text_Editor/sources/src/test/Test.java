package test;
/**
 * clasa principala de unde se lanseaza aplicatia
 */

import view.GUI_TextEditor;

public class Test {
	
	public static GUI_TextEditor g=new GUI_TextEditor();
	
	public static void main(String[] args){
		
		
	}

}
