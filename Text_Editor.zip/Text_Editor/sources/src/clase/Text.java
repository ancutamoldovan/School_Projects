package clase;

import java.awt.Color;

import java.awt.Font;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;


import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.JViewport;

import javax.swing.text.Document;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;



/**
 * se ocupa cu operatiile de baza efectuate asupra documentului
 * @author Moldovan Ancuta
 *
 */


public class Text {
	
	static JTabbedPane t;
	
	public Text(JTabbedPane t ){
		Text.t=t;
	}
	
	/**
	 * textpaneul selectat de utilizator
	 * @return jtextpane
	 */
	public static  JTextPane getTextPane(){
		
		JScrollPane scrollPane=(JScrollPane) t.getSelectedComponent();
		
		JViewport viewport = scrollPane.getViewport(); 
		JTextPane textPane = (JTextPane)viewport.getView();	
		
		return textPane;
	}
	
	/**
	 *  documentul selectat de utilizator
	 * @return
	 */
	
	public static Document getDocument(){
		
		Document doc = getTextPane().getDocument();
		
		return doc;
	}
	
	public static StyledDocument getStyledDocument(){
		StyledDocument doc = getTextPane().getStyledDocument();
		
		return doc;
	}
	
	
	public void selectAll(){
		getTextPane().selectAll();
	}
	/**
	 * aliniere text centru
	 */
	public void align_center(){
		
		StyledDocument doc=getStyledDocument();
		SimpleAttributeSet center = new SimpleAttributeSet();
    	StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
    	//doc.setParagraphAttributes(0, doc.getLength(), center, false);
    	doc.setParagraphAttributes(getTextPane().getSelectionStart(),getTextPane().getSelectionEnd(), center, false);
	}
	
	/**
	 * aliniere text stanga
	 */
	
	public void align_left(){
		
		StyledDocument doc=getStyledDocument();
		SimpleAttributeSet left = new SimpleAttributeSet();
    	StyleConstants.setAlignment(left, StyleConstants.ALIGN_LEFT);
    	//doc.setParagraphAttributes(0, doc.getLength(), left, false);
    	doc.setParagraphAttributes(getTextPane().getSelectionStart(),getTextPane().getSelectionEnd(), left, false);
	}
	
	/**
	 * aliniere text dreapta
	 */
	
	public void align_right(){
		
		StyledDocument doc=getStyledDocument();
		SimpleAttributeSet right = new SimpleAttributeSet();
    	StyleConstants.setAlignment(right, StyleConstants.ALIGN_RIGHT);
    	//doc.setParagraphAttributes(0, doc.getLength(), right, false);
    	doc.setParagraphAttributes(getTextPane().getSelectionStart(),getTextPane().getSelectionEnd(), right, false);
	}
	
	/**
	 * aliniere text potrivit
	 */
	
	public void align_justify(){
		
		 System.out.println(t.getSelectedComponent().toString());
		
		StyledDocument doc=getStyledDocument();
		SimpleAttributeSet justify = new SimpleAttributeSet();
    	StyleConstants.setAlignment(justify, StyleConstants.ALIGN_JUSTIFIED);
    	//doc.setParagraphAttributes(0, doc.getLength(), justify, false);
    	doc.setParagraphAttributes(getTextPane().getSelectionStart(),getTextPane().getSelectionEnd(), justify, false);
	}
	
	
	/**
	 * seteaza culoarea textului
	 * @param c - culoarea textului
	 */
	
	public void setColor(Color c){
		MutableAttributeSet attrs = getTextPane().getInputAttributes();


        // Set the font color
        StyleConstants.setForeground(attrs, c);

        // Retrieve the pane's document object
        StyledDocument doc = getTextPane().getStyledDocument();

        // Replace the style for the entire document. We exceed the length
        // of the document by 1 so that text entered at the end of the
        // document uses the attributes.
        
        //doc.setCharacterAttributes(getTextPane().getSelectionStart(), doc.getLength(), attrs, false);
        
        doc.setCharacterAttributes(getTextPane().getSelectionStart(), getTextPane().getSelectionEnd(), attrs, false);
        }
	/**
	 * seteaza fontul textului
	 * @param f - fontul selectat de utilizator
	 */
	public void setFont(Font f){
		MutableAttributeSet attrs = getTextPane().getInputAttributes();

       
        StyleConstants.setFontFamily(attrs, f.getFamily());
        StyleConstants.setFontSize(attrs, f.getSize());
        
        

        // Retrieve the pane's document object
        StyledDocument doc = getTextPane().getStyledDocument();

        // Replace the style for the entire document. We exceed the length
        // of the document by 1 so that text entered at the end of the
        // document uses the attributes.
      //  doc.setCharacterAttributes(getTextPane().getSelectionStart(), doc.getLength(), attrs, false);
        
        doc.setCharacterAttributes(getTextPane().getSelectionStart(), getTextPane().getSelectionEnd(), attrs, false);
	}
	
	/**
	 *  
	 * @param bold
	 */
	public  void setBold(int bold){
		
		MutableAttributeSet attrs = getTextPane().getInputAttributes();

		
		if (bold % 2 == 1 )
			attrs.addAttribute(StyleConstants.CharacterConstants.Bold, true);
		else 
			 attrs.addAttribute(StyleConstants.CharacterConstants.Bold, false);
			
        

        // Retrieve the pane's document object
        StyledDocument doc = getTextPane().getStyledDocument();

        // Replace the style for the entire document. We exceed the length
        // of the document by 1 so that text entered at the end of the
        // document uses the attributes.
        
        //doc.setCharacterAttributes(getTextPane().getSelectionStart(), doc.getLength(), attrs, false);
        
        doc.setCharacterAttributes(getTextPane().getSelectionStart(), getTextPane().getSelectionEnd(), attrs, false);
		
	}
	
	public void setItalic(int italic){
		
			
		
		MutableAttributeSet attrs = getTextPane().getInputAttributes();
		
		
		if (italic % 2 == 1 )
			attrs.addAttribute(StyleConstants.CharacterConstants.Italic, true);
		else 
			 attrs.addAttribute(StyleConstants.CharacterConstants.Italic, false);
        

        // Retrieve the pane's document object
        StyledDocument doc = getTextPane().getStyledDocument();

        // Replace the style for the entire document. We exceed the length
        // of the document by 1 so that text entered at the end of the
        // document uses the attributes.
        
      //  doc.setCharacterAttributes(getTextPane().getSelectionStart(), doc.getLength(), attrs, false);
        
        doc.setCharacterAttributes(getTextPane().getSelectionStart(), getTextPane().getSelectionEnd(), attrs, false);
		
	}
	
	public  void openTxtFile(File f){
		try  
        { 
      
           getTextPane().read(new FileReader(f), "");
         
        } 
		catch (IOException ioex) { 
            System.out.println("error open file"); 
            System.exit(1); 
        } 

		   }
	
	


}



