package clase;
/**
 * Clasa Fisier se ocupa cu efectuarea operatiilor asupra fisierului in care sunt stocate adresele carora
 * au fost trimise emailuri.
 */
import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.ImageIcon;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
/**
 * 
 * @author Moldovan Ancuta
 *
 */


public class Fisier {
	

	
	public Fisier(){
		
	}
	
	/**
	 * scrie in fisierul userului adresele carora au fost trimise emailuri
	 * @param filename - fisierul in care se scriu adresele de email
	 * @param mails - adresele de email 
	 */
	//se scriu in fisier adresele de email 
	public static void writeEmail(String filename,String mails){
		
		
		
		try {
			
			    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(filename, true)));
			    
			
			 //se separa adresele de email si se adauga in fisier
			 
			 StringTokenizer stringTokenizer=new StringTokenizer(mails, " ");
			 
			 while (stringTokenizer.hasMoreElements()){
				 String m=stringTokenizer.nextElement().toString();
				
					 out.print(m+"\n");
				 out.flush();
				 
			 }
		
				  
			 out.close();
		  
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	
	/**
	 *  returneaza adresele carora au fost trimise mailuri, dar care nu se afla in fisierul userului
	 * @param filename - fisierul din care se citesc emailurile
	 * @param mailuri - adresele recente de email
	 * @return un string ce contine adresele care nu se afla in fisier
	 */
	
	public static String  newMails(String filename,String mailuri){
		
		String adrese="";
		String text=readFile(filename);
		StringTokenizer m=new StringTokenizer(mailuri," ");
		
		while (m.hasMoreElements()){
			String mail=m.nextElement().toString();
			if (text.indexOf(mail)==-1)
				adrese=adrese+" "+mail;
		}
		
		return adrese;
		
	}
	
	/**
	 * se citeste fisierul si se returneaza continutul acestuia sub forma unui string
	 * @param filename - fisierul userului
	 * @return continutul fisierului
	 */
	//se citeste fisierul si se returneaza continutul acestuia sub forma unui string
	public static String readFile(String filename) {
	
		 String text=new String();
		 try{
			 FileReader read=new FileReader(filename);
			 BufferedReader in=new BufferedReader(read);
			 String str;
			 while ((str=in.readLine()) !=null){
				 
				 text+=str+"\n";
			 }
			 in.close();
		 }
		 catch(IOException e){
			 
		 }
		 
	
		 return text;
	}
	
	
	
	/**
	 * returneaza emailurile din fisier pentru a putea fi puse in jcombobox
	 * @param filename - fisierul cu emailuri
	 * @return un arraylist care contine emailurile
	 */
	
	//returneaza emailurile din fisier pentru a putea fi puse in jcombobox
	public static  ArrayList<String> getMails(String filename) {
		
		ArrayList<String> mails=new ArrayList<String>();
		
	
		 try{
			 FileReader read=new FileReader(filename);
			 BufferedReader in=new BufferedReader(read);
			 String str;
			 while ((str=in.readLine()) !=null){
				 mails.add(str);
				
			 }
			 in.close();
		 }
		 catch(IOException e){
			 
		 }
		 
		 return mails;
	}
	
	/**
	 * se creeaza fisierul utilizatorului in care se vor stoca adresele de email
	 * @param filename - fisierul utilizatorului 
	 */
	//se creeaza fisierul utilizatorului in care se vor stoca adresele de email
	
	public static void createFile(String filename){
		File f;
		  f=new File(filename);
		  if(!f.exists()){
		  try {
			f.createNewFile();
		} catch (IOException e) {
			System.out.println("eroare creare fisier");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  }
	}
	
	/**
	 * insereaza o imagine intr-un document
	 * @param f - calea imaginii care se va insera in document
	 */
	public static void insertImage(File f){
		
		System.out.println(f.getPath());
    	ImageIcon image = new ImageIcon(f.getPath());
    	
    	StyledDocument doc = Text.getTextPane().getStyledDocument();
		Style style = doc.addStyle("StyleName", null);
		
	
		if (image.getIconWidth() > 360) {
            ImageIcon image2 = new ImageIcon(image.getImage().
                                      getScaledInstance(360, -1,
                                                  Image.SCALE_DEFAULT));
            
		   
		    StyleConstants.setIcon(style, image2);
		}
		
		else 
			StyleConstants.setIcon(style, image);

		   
		    try {
		 
		    	 doc.insertString(doc.getLength(), " ", style);
		    } 
		    catch (BadLocationException badLocationException) {
		      System.err.println("Oops");
		    }
	}
	
	/**
	 * insereaza intr un document, un tabel cu numar de randuri si de coloane dat
	 * @param rows - numar randuri
	 * @param columns - numar coloane
	 */
	public static void insertTable(int rows,int columns){
		int pos=Text.getTextPane().getCaretPosition();
        DocxDocument doc=(DocxDocument)Text.getDocument();
        Element cell=doc.getCell(pos);
        SimpleAttributeSet attrs=new SimpleAttributeSet();
        BorderAttributes ba=new BorderAttributes();
        ba.setBorders(1+2+4+8+16+32);
        ba.lineColor=Color.black;
        attrs.addAttribute("BorderAttributes",ba);
        int[] widths=new int[columns];
        if (cell==null) {
            for (int i=0; i<widths.length; i++) {
                widths[i]=100;
            }
        }
        else {
            int width=((DocxDocument.CellElement)cell).getWidth()-4;
            for (int i=0; i<widths.length; i++) {
                widths[i]=width/columns;
            }
        }
        int[] heights=new int[rows];
        for (int i=0; i<heights.length; i++) {
            heights[i]=1;
        }
        doc.insertTable(pos,rows,columns,attrs,widths,heights);
	}

	
	
}
