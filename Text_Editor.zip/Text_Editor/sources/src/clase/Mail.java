package clase;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.StringTokenizer;


import javax.mail.Message;

import javax.mail.Multipart;
import javax.mail.Transport;

import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.text.Document;

import writer.DocxWriter;


/**
 * 
 * @author Moldovan Ancuta
 *
 */

public class Mail {
	
	private static ServerSettings settings;
	private static String from;
	private static String to;
	private static String subject;
	private static boolean bool;
	private static Transport transportSSL;
	private static String text; // daca e txt - textul din JtextPane, daca e docx - numele documentului
	private static Document doc;
	private static boolean txt;
	
	
	/**
	 * 
	 * @param settings - setarile pentru configurarea mailului
	 * @param from - adresa expeditorului
	 * @param to - adresa / adresele destinatarului / destinatarilor
	 * @param subject - subiectul emailului
	 * @param text - textul documentului, in caz ca e de tipul .txt
	 * @param txt - tipul documentului txt sau docx
	 */
	public Mail(ServerSettings settings,String from,String to,String subject,String text,boolean txt){
		
		Mail.from=from;
		Mail.to=to;
		Mail.subject=subject;
		Mail.settings=settings;
		Mail.text=text;
		Mail.txt=txt;
		
	}
	
	
	/**
	 * true- s a trimis mailul cu succes, false - a intervenit o eroare
	 * @return starea mailului, daca s-a trimis sau nu
	 */
	
	public boolean sendMail(){
		
		boolean trimis=false;
	
		
		try{
			
			Message messageSSL = new MimeMessage(settings.getSession());
			messageSSL.setFrom(new InternetAddress(from));
			
			 InternetAddress[] addressTo = new InternetAddress[getAdresses().size()];  
		     int counter = 0;  
		     for (String recipient : getAdresses()) {  
		          addressTo[counter] = new InternetAddress(recipient);  
		          counter++;  
		     }  
		     
			messageSSL.setRecipients(Message.RecipientType.TO, addressTo); // real recipient
			messageSSL.setSubject(subject);
			
			if (txt==true){
				
				//se trimite pur si simplu textul din jtextpane
				messageSSL.setText(text);
				System.out.println("email cu txt document");
			}
			
			else
			{
				//se creeaza un nou document cu continutul fisierului docx 
				try {
					//Text.getTextPane().getEditorKit().write(f.getAbsolutePath(),Text.getDocument());
        			 DocxWriter writer=new DocxWriter( Text.getDocument());
        		        writer.write(text);
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				//se ataseaza emailului
				
				Multipart mp = new MimeMultipart();
				
				byte[] attachmentData;
				 MimeBodyPart attachment = new MimeBodyPart();
			        attachment.setFileName(text);
			      
			        Path path = Paths.get(text);
			        attachmentData=Files.readAllBytes(path);
			    
			        attachment.setContent(attachmentData, "application/msword");
			        mp.addBodyPart(attachment);

			        messageSSL.setContent(mp);
				
				
				
			}

		
			if (goodPassword(settings.getUser().getUsername(),settings.getUser().getPassword())){
				transportSSL.sendMessage(messageSSL, messageSSL.getAllRecipients());
				trimis=true;
				transportSSL.close();
		       }
			
			

			
		}
		catch(Exception e){
			trimis=false;
			System.out.println("error");
		}
		
		return trimis;
		
		
	}
	
	
	
	
	

	public String getFrom() {
		return from;
	}


	public void setFrom(String from) {
		Mail.from = from;
	}


	public String getTo() {
		return to;
	}


	public void setTo(String to) {
		Mail.to = to;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		Mail.subject = subject;
	}
	
	/**
	 *  verifica corectitudinea parolei
	 * @param u - username
	 * @param p - password
	 * @return - true daca parola e corecta, false altfel
	 */
	public static boolean goodPassword(String u,String p){
		ServerSettings server=new ServerSettings("smtp.mail.yahoo.com", 465, new User(u,new String(p)));
		server.setServerSettings();
		
		bool=true;
		
		try {
			transportSSL = server.getSession().getTransport();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			
			System.out.println("nu se poate obtine sesiunea de lucru");
			e1.printStackTrace();
		}
		
		try
		{
			
			transportSSL.connect(server.getMailServer(),server.getPort(),u,p); // account used
		}
		catch(Exception e ){
			bool=false;
			System.out.println("adresa/parola incorecta");
		}
		
		return bool;
	}
	
	/**
	 * 
	 * @return adresele de email
	 */
	
	public ArrayList<String> getAdresses(){
	
		ArrayList<String> addresses=new ArrayList<String>();
		 StringTokenizer stringTokenizer=new StringTokenizer(to, " ");
		 
		 while (stringTokenizer.hasMoreElements())
			 addresses.add(stringTokenizer.nextElement().toString());
		 
		 return addresses;
	}


	public static Document getDoc() {
		return doc;
	}


	public static void setDoc(Document doc) {
		Mail.doc = doc;
	}
	
	

}
