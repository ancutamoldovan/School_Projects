/**
 * Clasa Filter creaza filtrele pentru imagini si fisiere
 * Pentru imagini -  jpg, bmp
 * Pentru fisiere - docx, txt
 */


package clase;


import java.io.File;

import javax.swing.filechooser.*;

/**
 * 
 * @author Moldovan Ancuta
 *
 */
public class Filter extends FileFilter {
	
	private String opt;
	
	/**
	 * opt = {fisier,imagine}
	 * @param opt - optiunea pe care vrem sa adaugam filtrul
	 */
	public Filter(String opt){
		this.opt=opt;
	}
	
	/**
	 * 
	 */

    public boolean accept(File f) {
    	
    	boolean accept=false;
    	
    
        if(f.isDirectory()) accept=true;
        
        if (opt.equals("file"))
        	accept = f.getName().toLowerCase().endsWith(".docx") || f.getName().toLowerCase().endsWith(".txt") ;
        if (opt.equals("image"))
        	accept = f.getName().toLowerCase().endsWith(".jpg") || f.getName().toLowerCase().endsWith(".bmp");
       
        return accept;
    }

 
    /**
     * 
     */
    public String getDescription() {
    	
    	String description = null;
    	
    	if (opt.equals("file"))
    		description=new String(".txt .docx");
    	if (opt.equals("image"))
    		description=new String(".jpg .bmp");
    	
		return description; 
    }
}