package clase;

import java.util.Properties;

import javax.mail.Session;

/**
 * Clasa ServerSetting configureaza setarile de mail 
 * @author Moldovan Ancuta
 *
 */
public class ServerSettings {

	private String mailServer;
	private int port;
	private User user;
	private Properties propsSSL ;
	private Session sessionSSL;
	
	/**
	 * 
	 * @param mailServer - serverul mailului
	 * @param port - portul
	 * @param user - user-ul
	 */
	public ServerSettings(String mailServer,int port,User user){
		
		this.mailServer=mailServer;
		this.port=port;
		this.user=user;
		
	}

	public String getMailServer() {
		return mailServer;
	}

	public void setMailServer(String mailServer) {
		this.mailServer = mailServer;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	/**
	 * configurare setari mail
	 */
	public void setServerSettings(){
		
		propsSSL = new Properties();
		
		propsSSL.put("mail.transport.protocol", "smtps");
		propsSSL.put("mail.smtps.host", getMailServer());
		propsSSL.put("mail.smtps.auth", "true");

		sessionSSL = Session.getInstance(propsSSL);
		sessionSSL.setDebug(true);
		
		System.out.println("s au configurat setarile de server");
	}

	public Session getSession() {
		// TODO Auto-generated method stub
		return sessionSSL;
	}

}
