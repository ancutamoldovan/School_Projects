package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import clase.Fisier;
import clase.Mail;


import view.GUI_Mail;

import view.GUI_User;

public class GUI_UserClick implements ActionListener{
	
	GUI_User g;
	
	public GUI_UserClick(GUI_User g){
		this.g=g;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		System.out.println("vrei sa te loghezi?");
		
		//metoda care se activeaza cand se apasa butonul log in
		
		String user=GUI_User.getUser();
		char[] password=GUI_User.getPassword();
		
		System.out.println("user:"+user);
		System.out.println("password:"+new String(password));
		System.out.println("parola corecta controller:"+Mail.goodPassword(user, new String(password).toString()));
		
		if ( Mail.goodPassword(user, new String(password))){
			//se creaza fisierul cu numele utilizatorului
			Fisier.createFile(user+".txt");
			
			//se deschide interfata pentru trimitere mail
			new GUI_Mail();
			
			// se inchide cea pentru user
	//		GUI_User.clearFields();
			GUI_User.dialog.setVisible(false);
		}
			
		else JOptionPane.showMessageDialog(null,
			    "Incorrect username or password",
			    "Error",
			    JOptionPane.ERROR_MESSAGE);
		
		
		
	}

}
