package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;





import view.GUI_ColorStyle;
import view.GUI_TextEditor;


public class GUI_ColorClick implements ActionListener{
	
	//GUI_ColorStyle g;
	String opt;
	
	public GUI_ColorClick(String opt){
	//	this.g=g;
		this.opt=opt;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		if (opt.equals("ok"))
		{
			
			
				GUI_TextEditor.text.setColor(GUI_ColorStyle.colorChooser.getColor());
				System.out.println("culoarea selectata este:"+GUI_ColorStyle.colorChooser.getColor().toString());
				GUI_ColorStyle.dialog.setVisible(false);
		        GUI_ColorStyle.dialog.dispose();
		        System.out.println("ok");
		       // System.out.println("highlight="+GUI_TextEditorClick.highlight);
			
			
			
			
		}
			
		if (opt.equals("none")){
			GUI_ColorStyle.dialog.setVisible(false);
	        GUI_ColorStyle.dialog.dispose();
	        System.out.println("none");
		}
			
		if (opt.equals("cancel"))
		{
			GUI_ColorStyle.dialog.setVisible(false);
	        GUI_ColorStyle.dialog.dispose();
			System.out.println("cancel");
		}
			
		
	}

}
