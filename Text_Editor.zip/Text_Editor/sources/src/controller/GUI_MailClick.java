package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JOptionPane;



import clase.Fisier;
import clase.Mail;
import clase.ServerSettings;
import clase.User;

import view.GUI_Mail;
import view.GUI_TextEditor;
import view.GUI_User;

public class GUI_MailClick implements ActionListener{
	
	
	private String b;
	private Mail mail;

	
	
	public GUI_MailClick(String b){
		this.b=b;
	
	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		System.out.println("to:"+GUI_Mail.getTo());
		System.out.println("subject"+GUI_Mail.getSubject());
		
		if (b.equals("tabbedPane")){
			System.out.println("tabbedpane");
		}
		
		if (b.equals("send")){
			System.out.println("send mail");
		
			
		
			
			User user=new User(GUI_User.getUser(),new String(GUI_User.getPassword()));
			
			if (GUI_TextEditorClick.val.get(GUI_TextEditor.tabbedPane.getSelectedIndex())==true)
				mail=new Mail(new ServerSettings("smtp.mail.yahoo.com", 465,user),user.getUsername(),GUI_Mail.getTo(),GUI_Mail.getSubject(),GUI_TextEditor.getText(),true);
			else 
				mail=new Mail(new ServerSettings("smtp.mail.yahoo.com", 465,user),user.getUsername(),GUI_Mail.getTo(),GUI_Mail.getSubject(),GUI_TextEditor.tabbedPane.getTitleAt(GUI_TextEditor.tabbedPane.getSelectedIndex())+".docx",false);
				
			if (mail.sendMail()==true){
				
				System.out.println("s-a trimis mailul cu succes");
				
				if (Fisier.newMails(GUI_User.getUser()+".txt",GUI_Mail.getTo()).equals(""))
					
					{
					JOptionPane.showMessageDialog(GUI_Mail.frame, "Email sent", "Confirm", JOptionPane.INFORMATION_MESSAGE);
					GUI_Mail.destinatar.setText("");
					GUI_Mail.subiect.setText("");
					GUI_Mail.textPane.setText("");
					
					}
				else
				{
					

				int n = JOptionPane.showConfirmDialog(
						  GUI_Mail.frame,
						    "Email sent"+"\n"+"" +
						    		"Would you like to add those new contacts to your email address book?",
						    "Confirm",
						    JOptionPane.YES_NO_OPTION);
				
				if (n==JOptionPane.YES_OPTION){
					String contacte=Fisier.newMails(GUI_User.getUser()+".txt",GUI_Mail.getTo());
					System.out.println("noile contacte:"+contacte);
					//se scriu noile adrese in fisier
					
					Fisier.writeEmail(GUI_User.getUser()+".txt",contacte);
					
					//se actualizeaza casuta cu adresele de email
					
					GUI_Mail.addItems(contacte);
					
					//se reseteaza casutele
					GUI_Mail.destinatar.setText("");
					GUI_Mail.subiect.setText("");
					GUI_Mail.textPane.setText("");
					
					
					
				}
					
				if (n==JOptionPane.NO_OPTION){
					System.out.println("nu intreprinde nicio actiune");
					GUI_Mail.destinatar.setText("");
					GUI_Mail.subiect.setText("");
					GUI_Mail.textPane.setText("");
					
				}
				
			}
			}
			else
				JOptionPane.showMessageDialog(
						  GUI_Mail.frame,
						    "Error sending email",
						    "Error",
						    JOptionPane.ERROR_MESSAGE);
			
	
			
			
		}
			
		if (b.equals("logOut")){
			//inchide fereastra cu mail, deschide o pe cea cu user
			System.out.println("log out");
		
			GUI_Mail.clearFields();
			GUI_User.clearFields();
			GUI_Mail.frame.setVisible(false);
			GUI_User.dialog.setVisible(true);
			
		}
		
		if (b.equals("combo")){
			System.out.println("actiuni ");
			
			
			 String mail = (String)GUI_Mail.combo.getSelectedItem();
		      GUI_Mail.destinatar.setText(GUI_Mail.getTo()+" "+mail);
		}
			
		
		
			
		
		
		
		
	}

}
