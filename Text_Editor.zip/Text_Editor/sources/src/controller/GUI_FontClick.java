package controller;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import clase.Text;

import view.GUI_FontStyle;
import view.GUI_TextEditor;

public class GUI_FontClick implements ActionListener {
	
	
	
	private String b;
	
	public GUI_FontClick(String b){
		this.b=b;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
	
		if (b.equals("ok")){
			
			String font=GUI_FontStyle.fontFamilyChooser.getSelectedItem().toString();
			int style=Text.getTextPane().getFont().getStyle();
			float size=Float.parseFloat((GUI_FontStyle.fontSizeChooser.getSelectedItem().toString()));
			
			
			System.out.println("start="+Text.getTextPane().getSelectionStart());
			System.out.println("end="+Text.getTextPane().getSelectionEnd());
			
			GUI_TextEditor.text.setFont(new Font(font,style,(int)size));
			System.out.println("font="+GUI_FontStyle.fontFamilyChooser.getSelectedItem()+"size="+GUI_FontStyle.fontSizeChooser.getSelectedItem());
			GUI_FontStyle.formatText.setVisible(false);
			//System.out.println("ok");
		}
		
		if (b.equals("cancel")){
			
			GUI_FontStyle.formatText.setVisible(false);
			System.out.println("cancel");
		}
		
		
	}

}
