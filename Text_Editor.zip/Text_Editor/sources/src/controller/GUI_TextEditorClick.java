package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;



import java.io.File;



import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import javax.swing.ScrollPaneConstants;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.BadLocationException;



import clase.DocxEditorKit;
import clase.Filter;
import clase.Fisier;
import clase.Text;

import com.inet.jortho.SpellChecker;





import test.Test;
import view.GUI_ColorStyle;

import view.GUI_FontStyle;

import view.GUI_Table;
import view.GUI_TextEditor;
import view.GUI_User;
import view.MouseMenu;
import writer.DocxWriter;


public class GUI_TextEditorClick  implements ActionListener, ChangeListener {
	
	private String optiune;
	private JFileChooser mfileChooser=new JFileChooser();
	private JFileChooser imageFileChooser=new JFileChooser();
	private static int i=0,t=0,d=0;
	int bold=0,italic=0;
	int enabled=0;//spellchecker
	static boolean txt=false;
	static ArrayList<Boolean> val=new ArrayList<>();
	JTextPane textDoc,textTxt;
	static MouseMenu mm;
	
	
	
	public GUI_TextEditorClick(String optiune){
	
		this.optiune=optiune;
		
		mfileChooser.setFileFilter(new Filter("file"));
		//mfileChooser.setAcceptAllFileFilterUsed(false);
		
		
		imageFileChooser.setFileFilter(new Filter("image"));
		//imageFileChooser.setAcceptAllFileFilterUsed(false);

	}

	


	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	
		// TODO Auto-generated method stub
	
	    
		// actiuni meniu File
		
	
		
		if (optiune.equals("txt")){
			
			
			
			//se activeaza opt txt
			txt=true;
			
			//se adauga in array tab ul la care s a activat optiunea txt
			
			
			System.out.println("you selected txt file: "+"i="+i+" txt="+txt);
			
			
			val.add(i, txt);
			i++;
			
			
			//se adauga tab ul corespunzator
			t++;
			
			textTxt=new JTextPane();
			
			mm=new MouseMenu(textTxt);	
			
		
			GUI_TextEditor.tabbedPane.add("txt "+t,new JScrollPane(textTxt,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED));
			GUI_TextEditor.tabbedPane.setSelectedIndex(i-1);
			
			//se dezactiveaza anumite optiuni
			
			GUI_TextEditor.disableOptionsDocx();
			
			
		}
		
		if (optiune.equals("docx")){
			
			
		
			txt=false;
		

			
			
			
			System.out.println("you selected docx file: "+"i="+i+" txt="+txt);
			
			val.add(i,txt);
			i++;
			
			d++;
			
			 textDoc=new JTextPane();
			 
			 mm=new MouseMenu(textDoc);
			 
			 textDoc.setEditorKit(new DocxEditorKit());
			 
			 
			GUI_TextEditor.tabbedPane.add("docx "+d,new JScrollPane(textDoc,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED));
			GUI_TextEditor.tabbedPane.setSelectedIndex(i-1);
			
			//sunt setate anumite optiuni corespunzatoare doar pentru docx
			
			GUI_TextEditor.enableOptionsDocx();
			
			
		}
		
		if (optiune.equals("open")){
			System.out.println("open");
			int retval = mfileChooser.showOpenDialog(Test.g);
            if (retval == JFileChooser.APPROVE_OPTION) { 
                File f = mfileChooser.getSelectedFile(); 
                
                if (val.get(GUI_TextEditor.tabbedPane.getSelectedIndex())==true)
                	if (f.getAbsolutePath().endsWith(".txt"))
                		GUI_TextEditor.text.openTxtFile(f);
                	else
                		
                		JOptionPane.showMessageDialog(Test.g,"You can open only .txt files!","Error",JOptionPane.ERROR_MESSAGE);
                	
               
             
                else
                	
                {
                	
                	if (f.getAbsolutePath().endsWith(".docx")){
						
							DocxEditorKit doc=new DocxEditorKit();
							 Text.getTextPane().setEditorKit(doc);
							try {
								doc.read(new FileInputStream(f), Text.getTextPane().getDocument(),0);
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (BadLocationException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
							System.out.println("s-a terminat incarcarea documentului");
                	}
                	
                	else
                		JOptionPane.showMessageDialog(Test.g,"You can open only .docx files!","Error",JOptionPane.ERROR_MESSAGE);
                		
					
                }
                	
                
                	
		
	}
		}
		
		
		if (optiune.equals("save")){
			System.out.println("save");
			
			int retval = mfileChooser.showSaveDialog(Test.g); 
            if (retval == JFileChooser.APPROVE_OPTION) { 
                File f = mfileChooser.getSelectedFile(); 
                
                System.out.println("fisierul tau se numeste:"+mfileChooser.getSelectedFile().getName());
                
                if (val.get(GUI_TextEditor.tabbedPane.getSelectedIndex())==true)
                	if (f.getAbsolutePath().endsWith(".txt"))
               
                    
                    try  
                    { 
                       FileWriter writer = new FileWriter(f); 
                       Text.getTextPane().write(writer);
                     
                    } 
                    catch (IOException ioex) { 
                        System.out.println("error save file"); 
                        System.exit(1); 
                    }
                
                	else 
                	{
                		
                		try {
								DocxWriter writer=new DocxWriter( Text.getDocument());
                		        writer.write(f.getAbsolutePath());
						} catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
                	}
                
                else 
                	if (f.getAbsolutePath().endsWith(".txt"))
                		JOptionPane.showMessageDialog(Test.g,"You can't save .txt files from .docx files","Error",JOptionPane.ERROR_MESSAGE);
                	else 
                	{
                		 
                 		try {
 						
                 			System.out.println("cale fisier:"+f.getAbsolutePath());
                 			 DocxWriter writer=new DocxWriter( Text.getDocument());
                 			 
                 		        writer.write(f.getAbsolutePath());
 						} catch (FileNotFoundException e1) {
 							// TODO Auto-generated catch block
 							e1.printStackTrace();
 						} catch (IOException e1) {
 							// TODO Auto-generated catch block
 							e1.printStackTrace();
 						}
						
                		
               
                	}
                } 
                  } 
   				   
                

		
		
		if (optiune.equals("close")){
			System.out.println("close");
			
			i--;
			GUI_TextEditor.tabbedPane.remove(GUI_TextEditor.tabbedPane.getSelectedIndex());
		}
		
		if (optiune.equals("exit")){
			System.out.println("exit");
			
			System.exit(0);
		}
		
		//actiuni meniu Edit
		
		if (optiune.equals("selectall")){
			
			Text.getTextPane().selectAll();
			
			System.out.println("selectall");
			
			
		}
		
		
			
			
		
		//actiuni submeniu Align
		
		if (optiune.equals("center")){
			
			GUI_TextEditor.text.align_center();
			System.out.println("center");
			
			
		}
		
		if (optiune.equals("left")){
			
			GUI_TextEditor.text.align_left();
			System.out.println("left");
			
			
		}
		
		if (optiune.equals("right")){
			
			GUI_TextEditor.text.align_right();
			System.out.println("right");
			
			
		}
		
		if (optiune.equals("justify")){
			
			GUI_TextEditor.text.align_justify();
			System.out.println("justify");
			
			
		}
		
		//actiuni submeniu Style
		
		if (optiune.equals("bold")){
			
	
			
			bold++;
			
			
				GUI_TextEditor.text.setBold(bold);
			
			
			System.out.println("bold="+bold);
			
			
		}
		
		if (optiune.equals("italic")){
			
			
			italic++;
			
			GUI_TextEditor.text.setItalic(italic);
			
		
		 
			System.out.println("italic="+italic);
			
			
		}
		
		if (optiune.equals("color")){
			
			
			
			new GUI_ColorStyle();
			  
		    System.out.println("color");
			
			
		}
		
		if (optiune.equals("font")){
			System.out.println("font&size");
			
			new GUI_FontStyle();
			
			
		}
		
		//actiuni submeniu Insert
		
		if (optiune.equals("table")){
			System.out.println("table");
			
			new GUI_Table();
			
			
        }
			
			
		
		if (optiune.equals("image")){
			System.out.println("image");
			
			
			
			int retval = imageFileChooser.showOpenDialog(Test.g);
            if (retval == JFileChooser.APPROVE_OPTION) { 
                File f = imageFileChooser.getSelectedFile(); 
                if (f.getAbsolutePath() != null)
                try  
                { 
              
              
                	
        			Fisier.insertImage(f);
        			
                 
                } catch (Exception ioex) {
                	System.err.println();
                    System.out.println("error open file"); 
                    
                } 
       
				   }
            
            
			
			
			
		}
		
		//actiune meniu Mail
		
		if (optiune.equals("mail")){
			System.out.println("mail");
			
			new GUI_User();
		}
		
		//actiuni meniu SpellChecker
		
		if (optiune.equals("enabled")){
			
			
			System.out.println("enabled");
			
			for(MouseListener listener : Text.getTextPane().getMouseListeners()){
                if(listener instanceof MouseAdapter) {
                    Text.getTextPane().removeMouseListener( listener );
                }
			}
			
			   // Load the configuration from the file dictionaries.cnf and 
	        // use the current locale or the first language as default 
	        try
	        {
	        	
	        	File configFile = new File("dictionaries.cnf");
	        	
	        	boolean exists = configFile.exists();
	        	System.out.println(exists);
	        	configFile = new File("dictionaries.cnf");
	        	
	        	exists = configFile.exists();
	        	
	        	URL url = new URL("file",null, "");	
	        	url=configFile.toURI().toURL();
	        	SpellChecker.registerDictionaries( url, null );
	        }
	        catch(MalformedURLException ex)
	        {
	        	ex.printStackTrace(System.out);
	        }


	        // enable the spell checking on the text component with all features
	        SpellChecker.register( Text.getTextPane() );
	        
	        
	
	        
	    }
			
			
		
		
		if (optiune.equals("disabled")){
			System.out.println("disabled");
			 SpellChecker.unregister( Text.getTextPane() );
			 
			  mm=new MouseMenu(Text.getTextPane());
			
		}	 
			 
			
			
		
		
		
}




	@Override
	public void stateChanged(ChangeEvent arg0) {
		
		
		if (optiune.equals("tab"))
			
		
			if (GUI_TextEditor.tabbedPane.getSelectedIndex()!=-1)
			if (val.get(GUI_TextEditor.tabbedPane.getSelectedIndex())!=null)
			{
				System.out.println("txt="+val.get(GUI_TextEditor.tabbedPane.getSelectedIndex()));
				
				if (val.get(GUI_TextEditor.tabbedPane.getSelectedIndex())==true)
					GUI_TextEditor.disableOptionsDocx();
				else GUI_TextEditor.enableOptionsDocx();
			}
		
		 
		
	}
	
	


	
	
	
	

}
