package controller;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;



import clase.Fisier;

import view.GUI_Table;


public class GUI_TableClick implements ActionListener {
	
	
	String b;
	
	public GUI_TableClick(String b){
		this.b=b;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

		if (b.equals("ok")){
			System.out.println("OK");
			
			//se citeste numarul de randuri si coloane
			
			
			int rows=GUI_Table.getRows();
			int columns=GUI_Table.getColumns();
			System.out.println("rows="+rows);
			System.out.println("columns="+columns);
			
		
			
			if ((rows>0) && (columns >0))
			{
				Fisier.insertTable(GUI_Table.getRows(),GUI_Table.getColumns());
				GUI_Table.dialog.setVisible(false);
				GUI_Table.dialog.dispose();
			}
	             
			
			else
			{
				JOptionPane.showMessageDialog(
			
						  GUI_Table.dialog,
						    "Please insert positive numbers!",
						    "Error",
						    JOptionPane.ERROR_MESSAGE);
				GUI_Table.clearFields();
			}
	            
			
			
		}
		
		
		if (b.equals("cancel")){
			
			GUI_Table.dialog.setVisible(false);
			GUI_Table.dialog.dispose();
			
			System.out.println("Cancel");
		}
	}
	
	

}
