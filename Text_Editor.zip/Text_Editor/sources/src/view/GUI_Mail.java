package view;
/**
 * fereastra pentru trimite mail
 */
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.StringTokenizer;


import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.Document;


import clase.Fisier;
import clase.Text;


import controller.GUI_MailClick;

public class GUI_Mail {
	
	
	
	//private static JComboBox<Object> combo;
	public static JTextField destinatar;
	public static JTextField subiect;
	public static JComboBox<Object> combo;
	public static JTextPane textPane;
	public static JFrame frame=new JFrame();
	private static JPanel panel,panel2,panel3;


	public GUI_Mail(){
		
		frame.setTitle("Username:"+GUI_User.getUser());
		frame.add(createPanel());
		frame.setLocationRelativeTo(null);
		frame.setSize(500,500);
		frame.pack();
		frame.setVisible(true);
		
	

		
		
	}
	
	public JPanel createPanel(){
		
		//pune si buton de new email in caz ca utilizatorul vrea sa trimita mai multe emailuri
		
		//vei crea o metoda care da reset la toate campurile+ revalidate + repaint
		
		 panel=new JPanel();
		 panel2=new JPanel();
		 panel3=new JPanel();
		
		
		
		combo=new JComboBox<Object>(Fisier.getMails(GUI_User.getUser()+".txt").toArray());
		
		
		
		panel.setLayout(new BorderLayout());
		
		JLabel label1=new JLabel("To:");
		JLabel label2=new JLabel("Subject:");
		
		 destinatar=new JTextField(20);
		 subiect=new JTextField(10);
		
		panel2.setLayout(new GridLayout(2,1));
		
		panel2.add(label1);
		panel2.add(destinatar);
		panel2.add(combo);
		panel2.add(label2);
		panel2.add(subiect);
		
		panel.add(panel2,BorderLayout.NORTH);
		
		textPane=new JTextPane();
		Document doc=Text.getDocument();
		textPane.setDocument(doc);
	
		//textPane.setText(GUI_TextEditor.getText());
		JScrollPane scrollPane=new JScrollPane(textPane);
		scrollPane.setPreferredSize(new Dimension(100,100));
		
		JButton send=new JButton("Send");
		JButton logOut=new JButton("Log Out");
		
		panel.add(scrollPane,BorderLayout.CENTER);
		panel3.add(send);
		panel3.add(logOut);
		
		send.addActionListener(new GUI_MailClick("send"));
		logOut.addActionListener(new GUI_MailClick("logOut"));
		combo.addActionListener(new GUI_MailClick("combo"));
		
		panel.add(panel3,BorderLayout.SOUTH);
		return panel;
	}
	
	

	//aici trebuie array list de email uri
	public static String getTo(){
		return destinatar.getText();
	}
	
	public static String getSubject(){
		return subiect.getText();
	}
	
	public static void addItems(String adrese){
		
		System.out.println("am intrat aici:"+adrese);
		StringTokenizer t=new StringTokenizer(adrese," ");
		while (t.hasMoreElements()){
			System.out.println("am intrat si aici");
			String m=t.nextElement().toString();
			System.out.println("adauga:"+m);
			combo.addItem(m);
		}
		
		panel2.revalidate();
		panel.revalidate();
	}
	
	
	public static void clearFields(){
		destinatar.setText("");
		subiect.setText("");
		combo.removeAllItems();
		textPane.setText("");
		frame.setTitle("Username:"+GUI_User.getUser());
	}
	
	
	
	
}
