package view;

/**
 * fereastra pentru logare
 */
import javax.swing.JButton;
import javax.swing.JDialog;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.GUI_UserClick;

public class GUI_User{

	
	
	public static JDialog dialog=new JDialog();
	private static JPasswordField password;
	private static JTextField user;
	

	public GUI_User(){
		
		
		dialog.setTitle("Log in ");
		dialog.setLocationRelativeTo(null);
		dialog.pack();
		dialog.setSize(400,100);
		dialog.add(createPanel());
		dialog.setVisible(true);	
		
		
	}
	
	public JPanel createPanel(){
		JPanel panel=new JPanel();
		
		JLabel label1=new JLabel("User");
		JLabel label2=new JLabel("Password");
		JButton log=new JButton("Log in");
		
		user=new JTextField(10);
		password=new JPasswordField(10); 
		
		panel.add(label1);
		panel.add(user);
		panel.add(label2);
		panel.add(password);
		panel.add(log);
		
		log.addActionListener(new GUI_UserClick(this));
		//panel.setSize(100,100);
		return panel;
	}
	
	/*public static void main(String[] args){
	new GUI_User();*/
	
	public static String getUser(){
		return user.getText();
	}
	
	public static char[] getPassword(){
		return password.getPassword();
	}
	
	public static void clearFields(){
		password.setText("");
		user.setText("");
	}
	
	
	
	

}
