package view;

/**
 * meniu optiuni text
 */
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.TransferHandler;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.JTextComponent;
import javax.swing.undo.UndoManager;
public class MouseMenu extends PopupMenu
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3135007551020219276L;
	private JTextComponent jTextComponent;
	private String cut;
	private String copy;
	private String paste;
	private String delete;
	private String selectAll;
	private String undo;
	private String redo;
	private UndoManager manager=new UndoManager();

	
	public MouseMenu(JTextComponent jTextComponent)
	{
		this(jTextComponent,"Cut", "Copy","Paste","Delete","SelectAll","Undo","Redo");
	}
	
	public MouseMenu(JTextComponent jTextComponent, String cut, String copy, String paste, String delete, String selectAll,String undo,String redo)
	{
		super();
		this.jTextComponent = jTextComponent;
		this.cut = cut;
		this.copy = copy;
		this.paste = paste;
		this.delete = delete;
		this.selectAll = selectAll;
		this.undo=undo;
		this.redo=redo;
		jTextComponent.add(this);
		
		MyListner myListner = new MyListner();
		UndoListener undoListener=new UndoListener();
		jTextComponent.addMouseListener(myListner);
		jTextComponent.getDocument().addUndoableEditListener(undoListener);
		addActionListener(myListner);
	}
	private void resetItem()
	{
		removeAll();
		
		boolean isTestSel = jTextComponent.getSelectedText()!=null;
		boolean isEditable = jTextComponent.isEditable();
		addMenuItem(cut, isTestSel && isEditable);
		addMenuItem(copy, isTestSel);
		addMenuItem(paste, isEditable);
		addMenuItem(delete, isEditable);
		addMenuItem(selectAll, isEnabled());
		addSeparator();
		addMenuItem(undo,isEnabled());
		addMenuItem(redo, isEnabled());
	}
	
	
	private void addMenuItem(String label, boolean isEnabled)
	{
		MenuItem menuItem = new MenuItem(label);
		menuItem.setEnabled(isEnabled);
		add(menuItem);
	}
	private void copy()
	{
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		TransferHandler transferHandler = jTextComponent.getTransferHandler();
		transferHandler.exportToClipboard(jTextComponent, clipboard, TransferHandler.COPY);
	}
	
	private void paste()
	{
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		TransferHandler transferHandler = jTextComponent.getTransferHandler();
		transferHandler.importData(jTextComponent, clipboard.getContents(null));
	}
	
	
	private class MyListner extends MouseAdapter implements ActionListener
	{
		@Override
		public void mousePressed(MouseEvent e) 
		{
			if(e.getButton() ==3)
			{
				resetItem();
				Point point = jTextComponent.getMousePosition();
				if(point!=null)
					show(jTextComponent,point.x,point.y);
			}
		}
		
		public void actionPerformed(ActionEvent e)
		{
			String source = e.getActionCommand();
			
			if(source.equals(copy))
				copy();
		
			else if(source.equals(paste))
				paste();
			
			else if(source.equals(cut))
			{
				copy();
				jTextComponent.replaceSelection("");
			}
			
			else if(source.equals(delete))
				jTextComponent.replaceSelection("");
			
			else if(source.equals(selectAll))
				jTextComponent.selectAll();
			
			else if (source.equals(undo)){
				
				try {
                    manager.undo();
            } 
				catch (Exception ex) {
					System.out.println("error undo");
            }
				System.out.println("undo");
				
			}
				
				
				
			else if (source.equals(redo)){
				
				System.out.println("redo");
				try{
					manager.redo();
				}
				catch(Exception ex){
					System.out.println("error redo");
				}
				
			}
				
		}

		

		
	}
	
	
	private class UndoListener implements UndoableEditListener{

		@Override
		public void undoableEditHappened(UndoableEditEvent arg0) {
			// TODO Auto-generated method stub
			
			
                         manager.addEdit(arg0.getEdit());
   
			
		}
		
	}
}