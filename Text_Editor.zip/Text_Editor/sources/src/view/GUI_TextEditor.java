package view;

/**
 * fereastra principala a proiectului
 */
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;



import clase.Text;

import controller.GUI_TextEditorClick;


public  class GUI_TextEditor extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static JTabbedPane tabbedPane=new JTabbedPane();
	public static Text text=new Text(tabbedPane);
	public static JMenu menuStyle;
	public static JMenu menuAlign;
	public static JMenu menuInsert;
	
	

	public GUI_TextEditor(){
		
		addComponents();
		
		
		
		
	}
	
	public void addComponents(){
		
		this.setLayout(new BorderLayout());
		this.setJMenuBar(createMenuBar());
		this.add(createPanel(),BorderLayout.CENTER);
		this.setTitle("TextEditor");
		this.setResizable(false);
		this.setSize(1000,700);
		this.setLocationRelativeTo(null);
		
		
		this.setVisible(true);
	}
	
	public JMenuBar createMenuBar(){
		
		JMenuBar menuBar=new JMenuBar();
		
		//meniu principal
		JMenu menuFile=new JMenu("File");
		JMenu menuEdit=new JMenu("Edit");
		JMenu menuMail=new JMenu("Mail");
		JMenu menuSpell=new JMenu("SpellChecker");
		
		//submeniu File
		
		JMenu menuNew=new JMenu("New");
		
		//submeniu New
		
		JMenuItem txt=new JMenuItem(".txt file");
		JMenuItem docx=new JMenuItem(".docx file");
		
		JMenuItem menuOpen=new JMenuItem("Open");
		JMenuItem menuSave=new JMenuItem("Save");
		JMenuItem menuClose=new JMenuItem("Close");
		JMenuItem menuExit=new JMenuItem("Exit");
		
		//submeniu Edit
		
		JMenuItem selectAll=new JMenuItem("Select all");

		
		menuAlign=new JMenu("Align");
		//submeniu Align
		JMenuItem align_left=new JMenuItem("Left");
		JMenuItem align_right=new JMenuItem("Right");
		JMenuItem align_center=new JMenuItem("Center");
		JMenuItem align_justify=new JMenuItem("Justify");
		
	 menuStyle=new JMenu("Style");
		//submeniu Style
		JMenuItem changeBold=new JMenuItem("Bold");
		JMenuItem changeItalic=new JMenuItem("Italic");
		JMenuItem changeColor=new JMenuItem("Color");
		JMenuItem changeFont=new JMenuItem("Font & Size");
		
		menuInsert=new JMenu("Insert");
		//submeniu Insert
		JMenuItem insertTable=new JMenuItem("Table");
		JMenuItem insertImage=new JMenuItem("Image");
		
		//submeniu Mail
		
		JMenuItem sendMail=new JMenuItem("Send mail ");
		
		//submeniu SpellChecker
		
		JMenuItem spell_enabled=new JMenuItem("Enabled");
		JMenuItem spell_disabled=new JMenuItem("Disabled");
		
		//adaugare elemente
		
		menuFile.add(menuNew);
		menuNew.add(txt);
		menuNew.add(docx);
		menuFile.add(menuOpen);
		menuFile.add(menuSave);
		menuFile.add(menuClose);
		menuFile.addSeparator();
		menuFile.add(menuExit);
		
		menuBar.add(menuFile);
		
		menuEdit.add(selectAll);
		menuAlign.add(align_left);
		menuAlign.add(align_right);
		menuAlign.add(align_center);
		menuAlign.add(align_justify);
		menuEdit.add(menuAlign);
		menuStyle.add(changeBold);
		menuStyle.add(changeItalic);
		menuStyle.add(changeColor);
		menuStyle.add(changeFont);
		menuEdit.add(menuStyle);
		menuInsert.add(insertTable);
		menuInsert.add(insertImage);
		menuEdit.add(menuInsert);
		
		menuBar.add(menuEdit);
		
		menuMail.add(sendMail);
		menuBar.add(menuMail);
		
		menuSpell.add(spell_enabled);
		menuSpell.add(spell_disabled);
		
		menuBar.add(menuSpell);
		
		//actiuni meniu File
		
		
		txt.addActionListener(new GUI_TextEditorClick("txt"));
		
		docx.addActionListener(new GUI_TextEditorClick("docx"));
		
		
		menuOpen.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O,
                java.awt.Event.CTRL_MASK));
	
		menuOpen.addActionListener(new GUI_TextEditorClick("open"));
		
		menuSave.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S,
                java.awt.Event.CTRL_MASK));
		menuSave.addActionListener(new GUI_TextEditorClick("save"));
		menuClose.addActionListener(new GUI_TextEditorClick("close"));
		menuExit.addActionListener(new GUI_TextEditorClick("exit"));
		
		//actiuni meniu Edit
		selectAll.addActionListener(new GUI_TextEditorClick("selectall"));
		
		//actiuni submeniu Align
		align_left.addActionListener(new GUI_TextEditorClick("left"));
		align_center.addActionListener(new GUI_TextEditorClick("center"));
		align_right.addActionListener(new GUI_TextEditorClick("right"));
		align_justify.addActionListener(new GUI_TextEditorClick("justify"));
		
		//actiuni submeniu Style
		
		changeBold.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B,
                java.awt.Event.CTRL_MASK));
		
		changeBold.addActionListener(new GUI_TextEditorClick("bold"));
		changeItalic.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I,
                java.awt.Event.CTRL_MASK));
		changeItalic.addActionListener(new GUI_TextEditorClick("italic"));
		changeColor.addActionListener(new GUI_TextEditorClick("color"));
		changeFont.addActionListener(new GUI_TextEditorClick("font"));
		
		//actiuni submeniu Insert
		insertImage.addActionListener(new GUI_TextEditorClick("image"));
		insertTable.addActionListener(new GUI_TextEditorClick("table"));
		
		//actiuni meniu Mail
		sendMail.addActionListener(new GUI_TextEditorClick("mail"));
		
		//actiuni meniu SpellChecker
		spell_disabled.addActionListener(new GUI_TextEditorClick("disabled"));
		spell_enabled.addActionListener(new GUI_TextEditorClick("enabled"));
		
		return menuBar;
	}
	
	public JTabbedPane createPanel(){
		
	

	    tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
	    tabbedPane.addChangeListener(new GUI_TextEditorClick("tab"));
	    
	
	   
	  

		return tabbedPane;
	}

	public static String getText() {
		// TODO Auto-generated method stub
		return Text.getTextPane().getText();
	}
	
	public static void enableOptionsDocx(){
		
		GUI_TextEditor.menuAlign.setEnabled(true);
		GUI_TextEditor.menuInsert.setEnabled(true);
		GUI_TextEditor.menuStyle.setEnabled(true);
	}
	
	public static void disableOptionsDocx(){
		GUI_TextEditor.menuAlign.setEnabled(false);
		GUI_TextEditor.menuInsert.setEnabled(false);
		GUI_TextEditor.menuStyle.setEnabled(false);
	}
	
	
}
