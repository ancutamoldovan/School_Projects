package view;

/**
 * fereastra pentru alegere nr randuri si coloane pentru inserarea tabelului in document
 */
import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.GUI_TableClick;

public class GUI_Table {
	
	
	public static JDialog dialog=new JDialog();
	private static JTextField rows;
	private static JTextField columns;
	
	public GUI_Table(){
		
		dialog.setModal(true);
		 dialog.getContentPane().setLayout(new BorderLayout());
		    dialog.getContentPane().add(createPanel(),BorderLayout.CENTER);
		    dialog.getContentPane().add(createButtons(), BorderLayout.SOUTH);
		    dialog.setTitle("Color");
		    //this.setModal(true);
		    dialog.pack();
		    dialog.setVisible(true);
		
	}
	
	public JPanel createPanel(){
		
		JPanel panel=new JPanel();
		
		JLabel r=new JLabel("Rows");
		JLabel c=new JLabel("Columns");
		
		rows=new JTextField(5);
		columns=new JTextField(5);
		
		panel.setLayout(new GridLayout(2,2));
		
		panel.add(r);
		panel.add(rows);
		panel.add(c);
		panel.add(columns);
		
	
		return panel;
		
	}
	
	public JPanel createButtons(){
		JPanel buttons=new JPanel();
		
		JButton ok=new JButton("OK");
		JButton cancel=new JButton("Cancel");
		
		buttons.add(ok);
		buttons.add(cancel);
		
		ok.addActionListener(new GUI_TableClick("ok"));
		cancel.addActionListener(new GUI_TableClick("cancel"));
		
		
		return buttons;
	}
	
	public static int getRows(){
		return Integer.parseInt(rows.getText());
		
		//return rows.getText();
	}
	
	public static int getColumns(){
		return Integer.parseInt(columns.getText());
	}
	
	public static void clearFields(){
		rows.setText("");
		columns.setText("");
	}
	

}
