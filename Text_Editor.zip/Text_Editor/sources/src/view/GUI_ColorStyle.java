package view;
/**
 *fereastra pentru alegerea culorii textului
 */
import java.awt.BorderLayout;


import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JDialog;

import javax.swing.JPanel;


import controller.GUI_ColorClick;

public class GUI_ColorStyle{

	public static JColorChooser colorChooser=new JColorChooser();
	public static JDialog dialog=new JDialog();
	
	
	public GUI_ColorStyle(){
		
		
		dialog.setModal(true);
		 dialog.getContentPane().setLayout(new BorderLayout());
		    dialog.getContentPane().add(colorChooser, BorderLayout.CENTER);
		    dialog.getContentPane().add(createPanel(), BorderLayout.SOUTH);
		    dialog.setTitle("Color");
		    //this.setModal(true);
		    dialog.pack();
		    dialog.setVisible(true);
		
	}
	
	JPanel createPanel(){
	
		  
		JPanel panel=new JPanel();
		JButton ok=new JButton("OK");
		JButton none=new JButton("None");
		JButton cancel=new JButton("Cancel");
		
		panel.add(ok);
		panel.add(none);
		panel.add(cancel);
		
		ok.addActionListener(new GUI_ColorClick("ok"));
		none.addActionListener(new GUI_ColorClick("none"));
		cancel.addActionListener(new GUI_ColorClick("cancel"));
		
		
		
		return panel;
	}
	
	/*public static void main(String[] args){
		new GUI_ColorStyle();
	}
	*/
	
	

}
