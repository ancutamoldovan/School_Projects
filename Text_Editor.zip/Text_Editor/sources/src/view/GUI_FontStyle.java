package view;
/**
 * fereastra pentru alegerea fontului textului
 */
import java.awt.BorderLayout;
import java.awt.GraphicsEnvironment;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.Element;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import clase.Text;


import controller.GUI_FontClick;

public class GUI_FontStyle  {
	
	GUI_TextEditor g;
	
	private String family;

	  private float fontSize;

	  public static JDialog formatText;

	  public static JComboBox<String> fontFamilyChooser;

	  public static JComboBox<Float> fontSizeChooser;
	
	public GUI_FontStyle(){
		//this.g=g;
		
		createPanel();
		
	}
	
	
	
	JDialog createPanel(){
		JPanel choosers=new JPanel();
		
		JTextPane editor=(JTextPane) Text.getTextPane();
		//JTextPane editor = (JTextPane) getEditor(e);
	    int p0 = editor.getSelectionStart();
	    StyledDocument doc = Text.getStyledDocument();
	    Element paragraph = doc.getCharacterElement(p0);
	    AttributeSet as = paragraph.getAttributes();

	    family = StyleConstants.getFontFamily(as);
	    fontSize = StyleConstants.getFontSize(as);
		
		formatText = new JDialog(new JFrame(), "Font and Size", true);
	    formatText.getContentPane().setLayout(new BorderLayout());
	    
	    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	    String[] fontNames = ge.getAvailableFontFamilyNames();

	    fontFamilyChooser = new JComboBox<String>();
	    for (int i = 0; i < fontNames.length; i++) {
	      fontFamilyChooser.addItem(fontNames[i]);
	    }
	    
	    JPanel fontFamilyPanel = new JPanel();
	    fontFamilyPanel.add(new JLabel("Font"));

	    fontFamilyChooser.setSelectedItem(family);
	    fontFamilyPanel.add(fontFamilyChooser);
	    choosers.add(fontFamilyPanel);
	    
	    JPanel fontSizePanel = new JPanel();
	    fontSizePanel.add(new JLabel("Size"));
	    
	  
	    
	    fontSizeChooser = new JComboBox<Float>();
	    fontSizeChooser.setEditable(true);
	    fontSizeChooser.addItem(new Float(4));
	    fontSizeChooser.addItem(new Float(8));
	    fontSizeChooser.addItem(new Float(12));
	    fontSizeChooser.addItem(new Float(16));
	    fontSizeChooser.addItem(new Float(20));
	    fontSizeChooser.addItem(new Float(24));
	    fontSizeChooser.setSelectedItem(new Float(fontSize));
	    fontSizePanel.add(fontSizeChooser);
	    choosers.add(fontSizePanel);
	    
	    
	    JButton ok = new JButton("OK");
	    JButton cancel = new JButton("Cancel");
	    
	    JPanel buttons = new JPanel();
	    buttons.add(ok);
	    buttons.add(cancel);
	    
	    ok.addActionListener(new GUI_FontClick("ok"));
	    cancel.addActionListener(new GUI_FontClick("cancel"));
	    //fontFamilyChooser.addActionListener(new GUI_FontClick("font"));
	    //fontSizeChooser.addActionListener(arg0)
	    
	    formatText.getContentPane().add(choosers, BorderLayout.CENTER);
	    formatText.getContentPane().add(buttons, BorderLayout.SOUTH);
	    formatText.setLocationRelativeTo(null);
	    formatText.pack();
	    formatText.setVisible(true);
	    formatText.setModal(true);
	    
		return formatText;
	}
	
	/*public static void main(String[] args){
		new GUI_FontStyle(new GUI_TextEditor());
	}*/

}
