import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.text.DefaultEditorKit;

/**
 * clasa GUI_Edit contine fereastra pentru efectuarea principalelor operatii asupra unui client al bancii si anume:
 * editarea de date personale,adaugare sau stergere de cont, depunere, retragere sau transfer de bani dintr un anumit cont
 * @author Moldovan Ancuta
 *
 */
public class GUI_Edit  implements MouseListener {
	
	JFrame f=new JFrame();
	JPanel panel=new JPanel();
	JLabel cnp,nume,prenume,adresa,nr_tel;
	JTextField CNP,Nume,Prenume,Adresa,Nr_tel;
	JButton save=new JButton("Save");
	JButton remove=new JButton("Remove");
	JButton add=new JButton("Add");
	JButton transfer=new JButton("Transfer");
	JButton retrage=new JButton("Retrage");
	JButton depune=new JButton("Depune");
	JTextArea textArea=new JTextArea(50,50);
	String newLine="\n";
	Action selectLine;
	Account account;
	Bank bank;
	String filename;
	
	/**
	 * Constructor de initializare
	 * @param filename - fisierul specific fiecarui client, care contine conturile acestuia
	 * @param account - un cont al clientului respectiv, care ne va ajuta la obtinerea informatiilor despre acesta
	 * @param bank -  banca careia apartine clientul
	 */
	
	public GUI_Edit(String filename,Account account,Bank bank){
		
		this.account=account;
		this.bank=bank;
		this.filename=filename;
		
		addComponents();
		
		citesteFisier();
		
	}
	
	/**
	 * creeaza fereastra pentru editarea clientului
	 */
	
	public void addComponents(){
		f.setTitle("edit");

		f.pack();
		f.setSize(900,500);
		f.setVisible(true);
		f.setLocation(500, 200);
		f.setLayout(new BorderLayout());
		
		f.add(createPanel());
	}
	
	/**
	 * creeaza un panou cu elementele necesare editarii informatiilor unui client
	 * @return un panou cu elementele necesare editarii informatiilor unui client
	 */
	
	public JPanel createPanel(){
		
		panel.setLayout(null);
		textArea.addMouseListener(this);
	    selectLine = getAction(DefaultEditorKit.selectLineAction);
		
		cnp=new JLabel("Cnp: ");
		cnp.setBounds(10,50,150,30);
		CNP=new JTextField(10);
		CNP.setBounds(65,50,150,30);
		CNP.setText(account.getPerson().getCnp());
		CNP.setEditable(false);
		nume=new JLabel("Nume: ");
		nume.setBounds(10,110,180,30);
		Nume=new JTextField(10);
		Nume.setBounds(80,110, 135,30);
		Nume.setText(account.getPerson().getNume());
		prenume=new JLabel("Prenume: ");
		prenume.setBounds(10,170,210 ,30);
		Prenume=new JTextField(10);
		Prenume.setBounds(95,170, 120,30);
		Prenume.setText(account.getPerson().getPrenume());
		adresa=new JLabel("Adresa: ");
		adresa.setBounds(10,230, 240,30);
		Adresa=new JTextField(10);
		Adresa.setBounds(120,230, 150,30);
		Adresa.setText(account.getPerson().getAdresa());
		nr_tel=new JLabel("Nr.tel:");
		nr_tel.setBounds(10,290,270,30);
		Nr_tel=new JTextField(10);
		Nr_tel.setBounds(135,290, 135,30);
		Nr_tel.setText(account.getPerson().getNrTel());
		transfer.setBounds(10,350,100,30);
		retrage.setBounds(150, 350, 100, 30);
		depune.setBounds(290,350,100,30);
		add.setBounds(10,410,100,30);
		remove.setBounds(150,410,100,30);
		save.setBounds(290,410,100,30);
		
		textArea.setBorder(new EtchedBorder());
		textArea.setEditable(false);
    	textArea.setBounds(500,50,150,100);
		
		panel.add(cnp);
		panel.add(CNP);
		panel.add(nume);
		panel.add(Nume);
		panel.add(prenume);
		panel.add(Prenume);
		panel.add(adresa);
		panel.add(Adresa);
		panel.add(nr_tel);
		panel.add(Nr_tel);
		
		panel.add(transfer);
		panel.add(retrage);
		panel.add(depune);
		panel.add(add);
		panel.add(remove);
		panel.add(save);
		
		transfer.setEnabled(false);
		retrage.setEnabled(false);
		depune.setEnabled(false);
		remove.setEnabled(false);
		
		System.out.println("clientul inainte de modificare:"+account.getPerson().toString());
		
		
		
		save.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               
	               modificaDate();
	              
                

	         
	           }
			});
		
		add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
            	       	
               System.out.print("add account");
               final Gui_addAccount y=new Gui_addAccount(bank,account.getPerson());
               
               class listenerOk implements ActionListener{

   				public void actionPerformed(ActionEvent arg0) {
   					
   					if (y.getVerificat()==true){
   						textArea.setText("");
   						citesteFisier();
   					}
   					
   				}
   				
   			}
   		 
   		 y.addListenerOk(new listenerOk());
            

         
           }
		});
		
		 remove.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               System.out.print("remove");
	              
	              int n =JOptionPane.showConfirmDialog(panel,
	                       "Are you sure?","Remove",
	                       JOptionPane.YES_NO_OPTION);
	              
	              if (n == JOptionPane.YES_OPTION) {
	                  //sterge clientul din fiser si din hashtable si implicit contul acestuia
	            	  System.out.println("Sterge contul clientului!");
	            	  bank.removeAccount(account.getPerson().getCnp(),getAccount(textArea.getSelectedText()));
	            	  textArea.setText("");
	            	  citesteFisier();
	              } 

	         
	           }
			});
	        
	        transfer.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               System.out.println("transfer");
	               
	              Gui_transfer x= new Gui_transfer(bank,account.getPerson(),textArea.getSelectedText());
	               
	               class listenerOk implements ActionListener{

	   				public void actionPerformed(ActionEvent arg0) {
	   					
	   					textArea.setText("");
	   					citesteFisier();
	   					
	   				}
	   				
	   			}
	   		 
	   		 x.addListenerOk(new listenerOk());
	              
	            

	         
	           }
			});
	        
	        retrage.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               System.out.println("retrage");
	               
	               Gui_retrage_depune x= new Gui_retrage_depune(bank,getAccount(textArea.getSelectedText()),0);
	               
	               class listenerOk implements ActionListener{

	      				public void actionPerformed(ActionEvent arg0) {
	      					
	      					textArea.setText("");
	      					citesteFisier();
	      					
	      				}
	      				
	      			}
	      		 
	      		 x.addListenerOk(new listenerOk());
	                 
	              
	            

	         
	           }
			});
	        
	        depune.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               System.out.println("depune");
	               
	             Gui_retrage_depune x=  new Gui_retrage_depune(bank,getAccount(textArea.getSelectedText()),1);
	               
	               class listenerSave implements ActionListener{

	   				public void actionPerformed(ActionEvent arg0) {
	   					
	   					textArea.setText("");
	   					citesteFisier();
	   					
	   				}
	   				
	   			}
	   		 
	   		 x.addListenerOk(new listenerSave()); 

	         
	           }
			});



	  

		
		panel.add(textArea);
		
		return panel;
	}
	
	/**
	 * 
	 * @param name
	 * @return
	 */
	
	private Action getAction(String name)
    {
        Action action = null;
        Action[] actions = textArea.getActions();
  
        for (int i = 0; i < actions.length; i++)
        {
            if (name.equals( actions[i].getValue(Action.NAME).toString() ) )
            {
                action = actions[i];
                break;
            }
        }
  
        return action;
    }
	
	/**
	 * 
	 */
  
    public void mouseClicked(MouseEvent e)
    {
  
        if ( SwingUtilities.isLeftMouseButton(e)  && textArea.getSelectedText()!="")
        {
		selectLine.actionPerformed(null);
		 System.out.println("ai selectat o linie");
		 
		 transfer.setEnabled(true);
		 retrage.setEnabled(true);
		 depune.setEnabled(true);
		 remove.setEnabled(true);
          }
        
       
  
        System.out.println(textArea.getSelectedText());
    
  
        }
    
    
    
  
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    
    /**
     * returneaza un obiect de tipul Person, care reprezinta clientul bancii, dar cu datele modificate
     * @return un obiect de tipul Person
     */
  
    public Person getClient(){
    	 	
    	String cnp=CNP.getText();
    	String nume=Nume.getText();
    	String prenume=Prenume.getText();
    	String adresa=Adresa.getText();
    	String nr_tel=Nr_tel.getText();
    	
    	
	
		return new Person(cnp, nume, prenume, adresa, nr_tel);
	}
    
    /**
     * in cazul in care se doreste modificarea datelor personale ale unui client,
     * aceasta metoda actualizeaza informatiile despre acesta
     */
    
    public void modificaDate(){
    	ArrayList<Account> lista=bank.getValues(account.getPerson().getCnp());
 
		Account[] conturi=new Account[lista.size()];
		for(int i=0;i<conturi.length;i++){
			conturi[i]=lista.get(i);
			System.out.println("i="+i+" "+conturi[i].getPerson().toString());
		}
		
		for(int i=0;i<conturi.length;i++){
			lista.set(i, new Account(conturi[i].getNr(),getClient(),conturi[i].getSold()));
			conturi[i]=lista.get(i);
		}
		
		bank.removeLineFromFile("clienti.txt",account.getPerson().toString());
		System.out.println("clientul dupa modificare:"+getClient().toString());
		bank.addClient("clienti.txt", getClient());
    	
    }
    
    /**
     * 
     * @param x actionlistener necesar pentru sincronizarea cu clasa care va crea un obiect de tipul GUI_Edit,
     * la apasarea butonului save, pentru actualizarea datelor personale ale clientului
     */
    
    public void addListenerSave(ActionListener x){
    	save.addActionListener(x);
	}
    
    /**
     * 
     * actionlistener necesar pentru sincronizarea cu clasa care va crea un obiect de tipul GUI_Edit,
     * la apasarea butonului transfer, pentru transferul unei sume de bani
     */
    
    public void addListenerOk(ActionListener x){
		transfer.addActionListener(x);
	}
    
    
    /**
     * citeste lista de conturi din fiserul clientului respectiv si o face vizibila utilizatorului
     */
    public void citesteFisier(){
    	
    	BufferedReader br=null;
	    try {
	    	br=new BufferedReader(new FileReader(filename));
	        textArea.read(br, null);
	        br.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
    	
    }
    
    /**
     * returneaza un obiect de tipul Account, creat cu ajutorul informatiilor extrase din linia selectata
     * de catre utilizator
     * @param sir - sir care contine informatiile referitoare la contul selectat de catre utilizator
     * @return un obiect de tipul Account
     */
    
    public Account getAccount(String sir){
    	StringTokenizer st=new StringTokenizer(sir,"	");
    	String c="";//cont
    	Double s=(double) 0;
    	
    	while(st.hasMoreElements()){
    		c=st.nextElement().toString();
    		s=Double.parseDouble(st.nextElement().toString());
    		
    		System.out.println("cont:"+c+" sold:"+s);
    		
    	}
    	
    	return new Account(c,account.getPerson(),s);
    	
    }

}
