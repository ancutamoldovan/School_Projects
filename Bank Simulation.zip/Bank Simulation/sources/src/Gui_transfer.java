import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * clasa Gui_transfer reprezinta fereastra necesare transferului unei sume de bani dintr-un cont al bancii, in alt cont
 * un obiect de tipul Gui_transfer este caracterizat de banca care contine clientii, clientul care efectueaza transferul de bani,
 * contul din care se transfera banii
 * @author Moldovan Ancuta
 *
 */

public class Gui_transfer extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel panel;
	JTextField Nr_cont,Suma;
	JButton ok;
	JLabel nr_cont,suma;
	Bank bank;
	Person client;
	String cont;
	
	/**
	 * Constructor de initializare
	 * @param bank - banca din care e fectueaza operatiile
	 * @param client - clientul care efectueaza tranzactia
	 * @param cont - contul din care se efectueaza tranzactia
	 */
	public Gui_transfer(Bank bank,Person client,String cont ){
		
		this.bank=bank;
		this.client=client;
		this.cont=cont;
		
		addComponents();
		
	}
	
	/**
	 * creaza fereastra pentru transferul de bani
	 */
	
	public void addComponents(){
		
		this.add(createPanel());
		this.setTitle("transfer");
		this.pack();
		this.setSize(200,150);
		this.setVisible(true);
		this.setLocation(500, 200);
		this.setLayout(new BorderLayout());
		
	}
	/**
	 * returneaza un panou care contine elementele necesare pentru transferul unei sume de bani
	 * @return un panou care contine elementele necesare pentru transferul unei sume de bani
	 */
	public JPanel createPanel(){
		
		panel=new JPanel();
		Nr_cont=new JTextField(10);
		Suma=new JTextField(10);
		nr_cont=new JLabel("Nr.cont:");
		suma=new JLabel("Suma:");
		ok=new JButton("OK");
		panel.add(nr_cont);
		panel.add(Nr_cont);
		panel.add(suma);
		panel.add(Suma);
		panel.add(ok);
		
		ok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
            	       	
               System.out.println("transfera bani");
               
               transferaBani();
            

         
           }
		});
		
		
		return panel;
		
		
	}
	
	/**
	 * returneaza un obiect de tipul Acoount
	 * @param sir - contul din care se transfera banii
	 * @return - un obiect de tipul Acoount
	 */
	
	 public Account getAccount(String sir){
	    	StringTokenizer st=new StringTokenizer(sir,"	");
	    	String c="";//cont
	    	Double s=(double) 0;
	    	
	    	while(st.hasMoreElements()){
	    		c=st.nextElement().toString();
	    		s=Double.parseDouble(st.nextElement().toString());
	    		
	    		System.out.println("cont:"+c+" sold:"+s);
	    		
	    	}
	    	
	    	return new Account(c,client,s);
	    	
	    }
	 
	 /**
	  * transfera o suma de bani din contul unui client in contul aceluiasi client sau al unui client diferit
	  */

	public void transferaBani(){
		
		Double s=Double.parseDouble(Suma.getText());
		Account x=getAccount(cont);
		String linie=x.getNr()+"\t"+x.getSold();
		Account y=bank.cautaNrCont(Nr_cont.getText());
		String cnp2=y.getPerson().getCnp();
		String linie2=y.getNr()+"\t"+y.getSold();
		String cnp=client.getCnp();
		System.out.println("cont gasit:"+bank.cautaNrCont(Nr_cont.getText()).toString());
		System.out.println("expeditor:"+bank.listToString(client.getCnp()));
		System.out.println("destinatar:"+bank.listToString(bank.cautaNrCont(Nr_cont.getText()).getPerson().getCnp()));
		
	
		
	x.transferMoney(bank.cautaNrCont(Nr_cont.getText()),s);
	
	System.out.println("expeditor:"+x.getSold());
	System.out.println("destinatar:"+bank.listToString(bank.cautaNrCont(Nr_cont.getText()).getPerson().getCnp()));
	
	bank.removeLineFromFile(cnp+".txt",linie);
	bank.writeAccount(cnp+".txt",x);
	
	bank.removeLineFromFile(cnp2+".txt",linie2	);
	bank.writeAccount(cnp2+".txt",y);
	
	//scrie detaliile in extrasele de cont ale clientilor
	Date data=new Date();
	
	String sir1= data.toString() + " transfer in contul:"+y.getNr()+" "+y.getPerson().getNume()+" "+y.getPerson().getPrenume()+" "+Suma.getText()+" sold="+x.getSold();
	String sir2= data.toString() + " depunere din contul:"+x.getNr()+" "+x.getPerson().getNume()+" "+x.getPerson().getPrenume()+" "+Suma.getText()+" sold="+y.getSold();
	
	scrieFisier("extras_"+cnp+".txt",sir1);
	scrieFisier("extras_"+cnp2+".txt",sir2);
		
		
	}
	
	 public void addListenerOk(ActionListener x){
			ok.addActionListener(x);
		}
	 
	 /**
	  * scrie informatii in extrasul de cont al clientului respectiv
	  * @param filename - fisierul care contine extrasul de cont al fisierului respectiv
	  * @param sir - informatia care se va scrie in extrasul de cont
	  */
	 public void scrieFisier(String filename,String sir){
			
		 String text=citesteFisier(filename);
		 FileWriter fstream;
		try {
			fstream = new FileWriter(filename);
			 BufferedWriter out=new BufferedWriter(fstream);
			 out.write(text+sir);
			 out.close();
		  
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	 
	 /**
	  * 
	  * @param filename - fisierul care contine extrasul de cont al clientului respectiv
	  * @return - continutul extrasului de cont
	  */
	 public String citesteFisier(String filename) {
		 String text=new String();
		 try{
			 FileReader read=new FileReader(filename);
			 BufferedReader in=new BufferedReader(read);
			 String str;
			 while ((str=in.readLine()) !=null){
				 text+=str+"\n";
			 }
			 in.close();
		 }
		 catch(IOException e){
			 
		 }
		 return text;
}
	
	
	
}