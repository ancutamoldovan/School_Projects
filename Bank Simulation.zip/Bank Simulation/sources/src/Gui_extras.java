import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
/**
 * clasa Gui_extras reprezinta fereastra care contine extrasul de cont al clientului respectiv
 * un obiect de tipul Gui_extras este caracterizat de banca careia apartine clientul si clientul al carui 
 * extras de cont vrem sa-l vedem
 * @author Moldovan Ancuta
 *
 */

public class Gui_extras{
	
	JFrame f=new JFrame();
	Bank bank;
	Person client;
	JPanel panel;
	JTextArea textArea;
	JScrollPane scrollPane;
	
	/**
	 * Constructor de initializare
	 * @param bank -  banca de care apartine clientul
	 * @param client - clientul care doreste sa si vizualizeze extrasul de cont
	 */
	
	public Gui_extras(Bank bank,Person client){
		this.bank=bank;
		this.client=client;
		addComponents();
	}
	/**
	 * contruieste ferestra pentru vizualizarea extrasului de cont
	 */
	public void addComponents(){
		
		
		f.add(createPanel());
		
		f.setTitle("extras cont "+client.getCnp());

		f.pack();
		f.setSize(500,300);
		f.setVisible(true);
		f.setLocation(500, 200);
		f.setLayout(new BorderLayout());

	}
	/**
	 * returneaza un panou, care contine extrasul de cont al clientului respectiv
	 * @return un panou ce contine extrasul de cont al clientului
	 */
	public JPanel createPanel(){
		
		panel=new JPanel();
		textArea=new JTextArea(10,40);
		textArea.setEditable(false);
		scrollPane=new JScrollPane(textArea);
		panel.add(scrollPane);
		citesteFisier();
		return panel;
	
	}
	
	/**
	 * citeste din fisier informatiile referitoare la extrasul de cont al clientului si le face vizibile utilizatorului
	 */
	
		public void citesteFisier(){

			BufferedReader br=null;
		    try {
		    	br=new BufferedReader(new FileReader("extras_"+client.getCnp()+".txt"));
		        textArea.read(br, null);
		        br.close();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		
	}
		
	
		
	

}
