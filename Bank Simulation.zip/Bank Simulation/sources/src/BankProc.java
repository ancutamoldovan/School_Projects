/**
 * interfata BankProc
 * @author Moldovan Ancuta
 *
 */
public interface BankProc {

	/**
	 * adauga un cont unui client al bancii
	 * @param cnp - cnp ul clientului caruia i se adauga contul
	 * @param account - contul care se adauga
	 */
	public void addAccount(String cnp,Account account);
	/**
	 * sterge contul unui client al bancii
	 * @param cnp - cnp-ul clientului caruia i se sterge contul
	 * @param account - contul care se sterge
	 */
	public void removeAccount(String cnp,Account account);
	/**
	 * scrie detaliile contului, in fisierul clientului respectiv
	 * @param filename - fisierul in care se va scrie contul
	 * @param account - contul din banca
	 */
	public void writeAccount(String filename,Account account);
	/**
	 * adauga un client bancii, si in acelasi timp il scrie in fisierul care contine clientii bancii
	 * @param filename - fisierul in care se va adauga clientul
	 * @param person - noul client al bancii
	 */
	public void addClient(String filename,Person person);
	/**
	 * fisierul din care se vor lua clientii bancii si datele acestora
	 * @param filename - fisierul din care se vor lua clientii bancii
	 */
	public void populate(String filename);
	/**
	 * sterge un client al bancii
	 * @param person - clientul care se va sterge
	 * @param filename - fisierul din care se va sterge clientul
	 */
	public void removeClient(Person person,String filename);
	/**
	 * cauta un cont in intreaga structura a bancii, si returneaza contul complet, cu toate detliile acestuia
	 * @param cont - numarul contului care se cauta in intreaga banca
	 * @return - un obiect de tip Account , care reprezinta contul complet
	 */
	public Account cautaNrCont(String cont);
	
}
