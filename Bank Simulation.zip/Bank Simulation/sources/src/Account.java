/**
 * Clasa Account defineste principalele operatii care se pot efectua pe un cont si anume:depunere,retragere
 * si transfer de bani
 * Un obiect de tipul Account este definit de nr de cont, persoana care il detine 
 * si soldul disponibil
 * @author Moldovan Ancuta
 *
 */
public class Account {

	String nr;
	Person client;
	double sold;
	
	public Account(){}
	
	/**
	 * Constructor de initializare 
	 * @param nr - contul clientului(numarul acestuia)
	 * @param client - clientul bancii
	 * @param sold - soldul pe care acesta il are in cont
	 */
	public Account(String nr,Person client,double sold){
		this.nr=nr;
		this.client=client;
		this.sold=sold;
	}
	/**
	 * Functie care actualizeaza soldul, dupa ce s-a depus o suma
	 * @param suma - suma de bani care se depune in contul existent
	 */
	public void savingMoney(double suma){
		this.sold+=suma;
	}
	
	/**
	 * Functie care actualizeaza soldul,dupa ce s-a retras o suma de bani
	 * @param suma - suma de bani care se retrage din contul existent
	 */
	
	public void spendingMoney(double suma){
		
		System.out.println("sold initial:"+this.sold);
		this.sold-=suma;
		System.out.println("sold final:"+this.sold);
		
	}
	
	/**
	 * Functie care transfera o suma de bani dintr-un cont in altul
	 * @param account - contul in care se va transfera suma de bani
	 * @param suma - suma de bani care se transfera din contul celui caruia efectueaza tranzactia
	 */
	public void transferMoney(Account account,double suma){	
		spendingMoney(suma);
		account.savingMoney(suma);
		
	}
	
	/**
	 * Functie care returneaza  contul unui client
	 * @return contul unui client
	 */
	
	public String getNr(){
		return nr;
	}
	
	/**
	 * Functie care returneaza suma de bani existenta intr un cont specificat
	 * @return suma de bani existenta in contul respectiv
	 */
	
	public double getSold(){
		return this.sold;
	}
	
	/**
	 * Functie care returneaza persoana care detine un cont anume
	 * @return persoana care detine contul respectiv
	 */
	
	public Person getPerson(){
		return client;
	}
	
	/**
	 * Functie care returneaza detaliile de baza ale unui cont si anume numarul acestuia si suma de bani disponibila
	 * @return contul si soldul existent
	 */
	
	public String toString(){
		return nr+"\t"+sold;
	}
	
	
}
