import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * Clasa GUI_ADD reprezinta fereastra pe care utilizatorul o foloseste pentru a adauga un nou client in banca respectiva
 * un obiect de tipul GUI_ADD este caracterizat de banca de care apartine clientul
 * 
 * @author Moldovan Ancuta
 *
 */

public class GUI_ADD  {
	
	JLabel cnp,nume,prenume,adresa,nr_tel,nr_cont;
	JTextField CNP,Nume,Prenume,Adresa,Nr_tel,Nr_cont;
	JButton save=new JButton("Save");
	JPanel panel=new JPanel();
	JFrame f=new JFrame();
	Bank bank;
	boolean verificat;
	
	/**
	 * Constructor de initializare
	 * @param bank - banca in care se va adauga clientul respectiv
	 */
	public GUI_ADD(Bank bank){
		
		this.bank=bank;
		addComponents();
	}
	
	/**
	 * creaza fereastra pentru adaugarea clientului
	 */
	
	public void addComponents(){
		
		f.setTitle("add");

		f.pack();
		f.setSize(200,300);
		f.setVisible(true);
		f.setLocation(500, 200);
		f.setLayout(new BorderLayout());
		f.add(createPanel());
		
	}
	/**
	 * creaza un panel, care contine elementele de baza pentru a crea un nou client al bancii
	 * @return un panel care va contine elementele pentru adaugarea clientului
	 */
	
	public JPanel createPanel(){
		
		cnp=new JLabel("Cnp: ");
		CNP=new JTextField(10);
		nume=new JLabel("Nume: ");
		Nume=new JTextField(10);
		prenume=new JLabel("Prenume: ");
		Prenume=new JTextField(10);
		adresa=new JLabel("Adresa: ");
		Adresa=new JTextField(10);
		nr_tel=new JLabel("Nr.tel:");
		Nr_tel=new JTextField(10);
		nr_cont=new JLabel("Nr_cont: ");
		Nr_cont=new JTextField(10);
		panel.add(cnp);
		panel.add(CNP);
		panel.add(nume);
		panel.add(Nume);
		panel.add(prenume);
		panel.add(Prenume);
		panel.add(adresa);
		panel.add(Adresa);
		panel.add(nr_tel);
		panel.add(Nr_tel);
		panel.add(nr_cont);
		panel.add(Nr_cont);
		
		save.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
    	       	
	            System.out.print("Save");
	           if ( verificareDate(CNP.getText(),Nr_tel.getText(),Nr_cont.getText())==false)
	        	   JOptionPane.showMessageDialog(panel,
	                       "Asigurati-va ca ati introdus corect datele",
	                       "Eroare",
	                       JOptionPane.ERROR_MESSAGE);
	           else {
	        	   System.out.println("date valide");
	        	   addClient();
	        	   verificat=true;
	        	   f.setVisible(false);
	           }
	            
	            }

	           
			});

		panel.add(save);
		
		return panel;
	}
	
	/**
	 * adauga clientul nou creat in baza de date a bancii
	 */
	
	public void addClient(){
		bank.addClient("clienti.txt", new Person(CNP.getText(),Nume.getText(),Prenume.getText(),Adresa.getText(),Nr_tel.getText()));
		bank.addAccount(CNP.getText(),new Account(Nr_cont.getText(),new Person(CNP.getText(),Nume.getText(),Prenume.getText(),Adresa.getText(),Nr_tel.getText()),(double)0));
		bank.writeAccount(CNP.getText()+".txt",new Account(Nr_cont.getText(),new Person(CNP.getText(),Nume.getText(),Prenume.getText(),Adresa.getText(),Nr_tel.getText()),0));
		
	}
	
	/**
	 * 
	 * @param x - actionlistener necesar pentru sincronizarea cu fereastra care va crea un obiect de tipul GUI_ADD
	 */
	
	public void addListenerSave(ActionListener x){
		 save.addActionListener(x);
	}
	
	/**
	 * returneaza true daca s-a apasat butonul save, si false in caz contrar
	 * @return un rezultat de tip boolean,care indica apasarea sau nu a butonului save
	 */
	
	public boolean getVerificat(){
		return verificat;
	}
	
	/**
	 * 
	 * @return un sir care contine datele personale ale unu client
	 */
	
	public String clientToString(){
		return  CNP.getText()+"\t"+Nume.getText()+" "+Prenume.getText()+"\tStrada. "+Adresa.getText()+"\tnr.tel: "+Nr_tel.getText();
	}
	
	/**
	 * functie care verifica daca datele introduse sunt corecte, si returneaza true,sau false in functie de
	 * corectitudinea acestora
	 * @param c - cnp ul clientului
	 * @param nr - numarul de telefon al cleintului
	 * @param cont - numarul de cont al clientului
	 * @return - true sau false, in functie de corectitudinea datelor introduse
	 */
	
  	public boolean verificareDate(String c,String nr ,String cont){
  		
  		boolean rezultat=true;
  		
  		if ((c.length()!=13) || ((c.charAt(0)!='2') && (c.charAt(0)!='1')) || (Integer.parseInt(c.substring(1,3))>94)) 
  			rezultat=false;
  		
  		System.out.println("cnp:"+rezultat);
  		
  		if (nr.length()!=10) rezultat=false;
  		
  		System.out.println("nr:"+rezultat);
  		
  		
  		if (cont.length()!=11) rezultat=false;
  		System.out.println("lungime cont:"+rezultat);
  		if (bank.cautaNrCont(cont)!=null) rezultat=false;
  		System.out.println("cont existent:"+rezultat);
  		
  		System.out.println("etapa urmatoare:"+rezultat);
  		
  		System.out.println("rezultat"+rezultat);
  		
  		return rezultat;
  		
  		
  		
	}
	
	


	

}
