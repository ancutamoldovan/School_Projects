import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.StringTokenizer;
/**
 * 
 * @author Moldovan Ancuta
 *
 */

public class Bank implements BankProc {
	
	public static Hashtable<String,ArrayList<Account>> accounts;
	
	/**
	 * constructor de initializare
	 */
	public Bank(){
		accounts=new Hashtable<String,ArrayList<Account>> ();
	}
	
	/**
	 * adauga un cont unui client al bancii
	 * @param cnp - cnp ul clientului caruia i se adauga contul
	 * @param account - contul care se adauga
	 */
	public void addAccount(String cnp, Account account)
	{
		//adaugare cont in Hashtable
		
		ArrayList<Account> values = accounts.get(cnp);
		if (values == null) {
			values = new ArrayList<Account>();
		}
		if (!values.contains(account)) {
			values.add(account);
			accounts.put(cnp, values);
		}
		
		
	}
	
	/**
	 * sterge contul unui client al bancii
	 * @param cnp - cnp-ul clientului caruia i se sterge contul
	 * @param account - contul care se sterge
	 */
	public void removeAccount(String cnp,Account account){
		
		//se sterge contul respectiv din hastable
		accounts.get(cnp).remove(account);
		//se sterge contul respectiv din fisier
		removeLineFromFile(cnp+".txt",account.getNr()+"\t"+account.getSold());

		
	}
	
	/**
	 * scrie detaliile contului, in fisierul clientului respectiv 
	 * @param filename - fisierul in care se va scrie contul
	 * @param account - contul din banca
	 */
	public void writeAccount(String filename,Account account){
		

		 String text=readFile(filename);
		 FileWriter fstream;
		try {
			fstream = new FileWriter(filename);
			 BufferedWriter out=new BufferedWriter(fstream);
			 out.write(text+account.getNr()+"\t"+account.getSold());
			 out.close();
		  
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	
	//de fiecare data cand se deschide programul, se initializeaza HashTable
	/**
	 * fisierul din care se vor lua clientii bancii si datele acestora
	 * @param file1 - fisierul din care se vor lua clientii bancii
	 * @pre file1!="" && accounts.size()==0
	 * @post accounts.size()!=0
	 */
	public void populate(String file1){
		
		assert file1.equals("")==false && accounts.size()==0;
		assert isWellFormed();
		
		 BufferedReader br = null;
		 String nume="",prenume="";
		
		try {
			 
			String line;
	 
			br = new BufferedReader(new FileReader(file1));
	 
			while ((line = br.readLine()) != null) {
				
				System.out.println(line);
	 
			   StringTokenizer stringTokenizer = new StringTokenizer(line, "	");
	 
			   while (stringTokenizer.hasMoreElements()) {
				   
				   //obtinem informatiile despre client
				   
				   String cnp=stringTokenizer.nextElement().toString();
				   System.out.println("cnp="+cnp);
				   String nume_prenume=stringTokenizer.nextElement().toString();
					
					StringTokenizer st1=new StringTokenizer(nume_prenume," ");
					
					while (st1.hasMoreElements()){
					 nume=st1.nextElement().toString();
				 	prenume=st1.nextElement().toString();
					}
					
				String adresa=stringTokenizer.nextElement().toString();
				String 	nr_tel=stringTokenizer.nextElement().toString();
				
				//cream un nou client de fiecare data cand am terminat de citit o linie
				
				Person client=new Person(cnp,nume,prenume,adresa,nr_tel);
				
				//citim conturile fiecarui client
				
				BufferedReader br1=null;
				String nr_cont="";
				double sold=0;
				
				try {
					 
					String line1;
			 
					br1 = new BufferedReader(new FileReader(cnp+".txt"));
			 
					while ((line1 = br1.readLine()) != null) {
			 
					   StringTokenizer stringTokenizer1 = new StringTokenizer(line1, "	");
			 
					   while (stringTokenizer1.hasMoreElements()) {
						   nr_cont=stringTokenizer1.nextElement().toString();
						   sold=Double.parseDouble(stringTokenizer1.nextElement().toString());
						   
						 //in acest moment, avem toate inf necesare crearii unui nou Account
							
							Account account=new Account(nr_cont,client,sold);
						   System.out.println(nr_cont+" "+sold);
							
						//adaugam contul in HashTable
						  
							addAccount(cnp, account);
					
					   }
					}
			 
					System.out.println("Done2");
			 
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						if (br1 != null)
							br1.close();
			 
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
				
				
				
				
			
			   }
			}
	 
			System.out.println("Done");
	 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
	 
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		assert accounts.size()!=0;
		
	}
	
	/**
	 * returneaza conturile unui client
	 * @param key - cnp ul clienului
	 * @pre key!=null
	 * @post nochange
	 * @return - un sir care contine conturile clientului
	 */
	
	public String listToString(String key){
		assert key!=null;
		String s="";
		Iterator<?> i=accounts.get(key).iterator();
		
		while(i.hasNext()){
			s=s+i.next().toString();
		}
		return s;
	}
	
	/**
	 * returneaza un ArrayList ce contine conturile unui client
	 * @param key - cnp ul unui client
	 * @pre key!=null
	 * @post @nochange
	 * @return - un ArrayList ce contine conturile unui client
	 */
	public ArrayList<Account> getValues(String key){
		assert key!=null;
		return accounts.get(key);
	}
	
	/**
	 * returneaza o enumerare care contine cnp urile clientilor bancii
	 * @pre accounts!=null
	 * @post @nochange
	 * @return o enumerare care contine cnp urile clientilor bancii
	 */
	public Enumeration<String> getKeys(){
		assert	accounts!=null;
		return accounts.keys();
	}

	/**
	 * returneaza continutul unui fisier
	 * @param filename - fisierul din care se citesc datele
	 * @return - un sir care contine continutul fisierului
	 * @pre filename!=""
	 * @post @nochange
	 */
	public String readFile(String filename) {
			assert filename.equals("")==false;
			 String text=new String();
			 try{
				 FileReader read=new FileReader(filename);
				 BufferedReader in=new BufferedReader(read);
				 String str;
				 while ((str=in.readLine()) !=null){
					 text+=str+"\n";
				 }
				 in.close();
			 }
			 catch(IOException e){
				 
			 }
			 return text;
	}
	
	/**
	 * adauga un client bancii, si in acelasi timp il scrie in fisierul care contine clientii bancii
	 * creaza un fisier care contine conturile acestuia si un fisier care reprezinta extrasul de cont al acstuia
	 * @param filename - fisierul in care se va adauga clientul
	 * @param person - noul client al bancii
	 */
	public void addClient(String filename, Person person) {
		//se adauga clientul in fisierul cu clienti
		
		String text=readFile(filename);
		 FileWriter fstream;
		try {
			fstream = new FileWriter(filename);
			 BufferedWriter out=new BufferedWriter(fstream);
			 out.write(text+person.toString());
			 out.close();
		  
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
		//se creaza un fisier care va contine conturile acestuia
		File f=new File(person.getCnp()+".txt");
		if(!f.exists()){
			  try {
				f.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//se creaza un fisier care reprezinta extrasul de cont al acestuia
		
		File f2=new File("extras_"+person.getCnp()+".txt");
		if(!f2.exists()){
			  try {
				f2.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	/**
	 * sterge un client al bancii,impreuna cu extrasul de cont al acestuia si fisierul cu conturi al acestuia
	 * @param client - clientul care se va sterge
	 * @param filename - fisierul din care se va sterge clientul
	 */
	public void removeClient(Person client, String filename) {
		
		//stergem clientul din hashtable
		accounts.remove(client.getCnp());
		//stergem clientul din fisier
		removeLineFromFile(filename,client.toString());
		//stergem fisierul cu conturile acestuia
		boolean success = (new File(client.getCnp()+".txt")).delete();
		if (!success) {
		    System.out.println("Deletion failed");
		}
		//stergem fisierul care contine extrasul de cont al clientului
		boolean success2 = (new File("extras_"+client.getCnp()+".txt")).delete();
		if (!success2) {
		    System.out.println("Deletion 2 failed");
		}
		
		assert accounts!=null;
		
	}
	/**
	 * sterge o linie dintr un fisier
	 * @param file - fisierul din care se va sterge linia
	 * @param lineToRemove - linia pe care dorim sa o stergem
	 * @pre file!="" && lineToRemove!=""
	 * @post
	 */
	public void removeLineFromFile(String file, String lineToRemove) {
		
		assert file.equals("")==false && lineToRemove.equals("")==false;

	    try {

	      File inFile = new File(file);
	      
	      if (!inFile.isFile()) {
	        System.out.println("Parameter is not an existing file");
	        return;
	      }
	       
	      //construieste un nou fisier care va fi redenumit mai tarziu cu numele fisierului original
	      
	      File tempFile = new File(inFile.getAbsolutePath() + ".tmp");
	      
	      BufferedReader br = new BufferedReader(new FileReader(file));
	      PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
	      
	      String line = null;
	      
	      //citeste din fisierul original si scrie in cel nou
	      //pana cand se gaseste linia pe care vrem sa o stergem
	      
	      while ((line = br.readLine()) != null) {
	        
	        if (!line.trim().equals(lineToRemove)) {
	        	
	        	System.out.println("s-a gasit linia");

	          pw.println(line);
	          pw.flush();
	        }
	      }
	      pw.close();
	      br.close();
	      
	      //sterge fisierul original
	      if (!inFile.delete()) {
	        System.out.println("Could not delete file");
	        return;
	      } 
	         
	      //redenumeste fisierul nou cu numele fisierului original
	   
	      if (!tempFile.renameTo(inFile))
	        System.out.println("Could not rename file");
	      
	    }
	    catch (FileNotFoundException ex) {
	      ex.printStackTrace();
	    }
	    catch (IOException ex) {
	      ex.printStackTrace();
	    }
	}
	
	/**
	 * cauta un cont in intreaga structura a bancii, si returneaza contul complet, cu toate detliile acestuia
	 * @param cont - numarul contului care se cauta in intreaga banca
	 * @return - un obiect de tip Account , care reprezinta contul complet
	 * @pre cont !="" && accounts.size()>0
	 * @post @nochange
	 */
	
	public  Account cautaNrCont(String cont){
		
		assert cont.equals("")==false && accounts.size()>0;
		Enumeration<String> en = (Enumeration<String>) accounts.keys();
				
		while(en.hasMoreElements()){
			String key = (String) en.nextElement();
			ArrayList<Account> lista=getValues(key);
			Account[] conturi=new Account[lista.size()];
			for(int i=0;i<conturi.length;i++){
				conturi[i]=lista.get(i);
				if (conturi[i].getNr().equals(cont)) return conturi[i];
		
			}
		}
			
			
		return null;
		 
		
	}
	
	/**
	 * @invariant isWellFormed()
	 * @return boolean
	 */
	
	public boolean isWellFormed(){
		
		Enumeration<String> en = (Enumeration<String>) accounts.keys();
		int n=0;
		while (en.hasMoreElements()){
			n++;
		}
		
		return n==accounts.size();

	}
	
	
	
	
	
	}


