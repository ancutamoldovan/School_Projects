import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * clasa Gui_retrage_depune contine fereastra principala pentru retragerea,respectiv depunerea unei sume de bani
 * intr un cont
 * un obiect de tipul Gui_retrage_depune este caracterizat de banca care contine clientul, contul din care se doreste sa se 
 * efectueze o operatie si de decizie, variabila care desemneaza ce operatie se va efectua:retragere sau depunere de bani
 * @author Moldovan Ancuta
 *
 */

public class Gui_retrage_depune{
	
	JFrame f=new JFrame();
	JPanel panel;
	JButton ok;
	JTextField Suma;
	JLabel suma;
	int decizie;//decizie=0-retrage,decizie=1-depune
	Bank bank;
	Account account;
	
	/**
	 * Constructor de initializare
	 * @param bank - banca in care se va efectua operatia
	 * @param account - contul din care se doreste depunerea/retragerea unei sume de bani
	 * @param decizie - variablia de decizie 0-retragere/1-depunere de bani
	 */
	public Gui_retrage_depune(Bank bank,Account account,int decizie){
		this.bank=bank;
		this.account=account;
		this.decizie=decizie;
		
		addComponents();
	}
	/**
	 * creaza fereastra pentru retragere/depunerea sumei de bani
	 */
	public void addComponents(){
		f.add(createPanel());
		f.setTitle("");
		f.pack();
		f.setSize(200,100);
		f.setVisible(true);
		f.setLocation(500, 200);
		f.setLayout(new BorderLayout());
	}
	
	/**
	 * 
	 * @return un panou care contine elementele necesare depunerii/retragerii sumei de bani
	 */
	
	public JPanel createPanel(){
		
		panel=new JPanel();
		Suma=new JTextField(10);
		suma=new JLabel("Suma:");
		ok=new JButton("OK");
		panel.add(suma);
		panel.add(Suma);
		panel.add(ok);
		
		ok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
            	       	
               if (decizie==0) {
            	   System.out.println("retrage bani");
            	   retrageBani();
            	   f.setVisible(false);
               }
               			else {System.out.println("depune bani");
               			depuneBani();
               			f.setVisible(false);
               			}     

         
           }
		});
		
		
		return panel;
		
		
	}
	
	/**
	 * retrage bani din contul respectiv al unui client, si actualizeaza informatiile din contul acestuia,
	 * memorand in acelasi timp detaliile retragerii in  extrasul de cont al clientului
	 */

	public void retrageBani(){
		
		bank.removeLineFromFile(account.getPerson().getCnp()+".txt",account.toString());
		account.spendingMoney(Double.parseDouble(Suma.getText()));
		bank.writeAccount(account.getPerson().getCnp()+".txt", account);
		
		//se scriu detaliile retragerii in extrasul de cont al clientului
		String sir=new Date().toString()+" depunere suma de: "+Suma.getText()+" sold="+account.getSold();
		scrieFisier("extras_"+account.getPerson().getCnp()+".txt", sir);
		
		
	}
	
	/**
	 * depune bani in contul respectiv al unui client, si actualizeaza informatiile din contul acestuia,
	 * memorand in acelasi timp detaliile depunerii in extrasul de cont al clientului
	 */
	
	public void depuneBani(){
		
		bank.removeLineFromFile(account.getPerson().getCnp()+".txt",account.toString());
		account.savingMoney(Double.parseDouble(Suma.getText()));
		bank.writeAccount(account.getPerson().getCnp()+".txt", account);
		
		//se scriu detaliile depunerii in extrasul de cont al clientului
		
		String sir=new Date().toString()+" retragere suma de: "+Suma.getText()+" sold="+account.getSold();
		scrieFisier("extras_"+account.getPerson().getCnp()+".txt", sir);
		
		
	}
	
	/**
	 * actionlistener adaugat butonului ok, pentru sincronizarea cu clasa care va crea un obiect de tipul
	 * Gui_retrage_depune
	 */
	  
	 
	
	public void addListenerOk(ActionListener x){
		ok.addActionListener(x);
	}
	
	/**
	 * actualizeaza extrasul de cont al clientuli pe masura ce se efectueaza cate o operatie de retragere/depunere
	 * @param filename - fisierul care contine extrasul de cont al clientului respectiv
	 * @param sir - informatiile referitoare la detaliile operatiilor efectuate de client
	 */
	 public void scrieFisier(String filename,String sir){
			
		 String text=citesteFisier(filename);
		 FileWriter fstream;
		try {
			fstream = new FileWriter(filename);
			 BufferedWriter out=new BufferedWriter(fstream);
			 out.write(text+sir);
			 out.close();
		  
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}
	 
	 /**
	  * 
	  * @param filename - fisierul care contine extrasul de cont al clientului
	  * @return - continutul fisierului
	  */
	 
	 public String citesteFisier(String filename) {
		 String text=new String();
		 try{
			 FileReader read=new FileReader(filename);
			 BufferedReader in=new BufferedReader(read);
			 String str;
			 while ((str=in.readLine()) !=null){
				 text+=str+"\n";
			 }
			 in.close();
		 }
		 catch(IOException e){
			 
		 }
		 return text;
}
	

	
	
	

}
