import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

/**
 * clasa GUI_Clienti reprezinta fereastra principala care se va deschide la rularea aplicatiei
 * 
 * @author Moldovan Ancuta
 *
 */
public class GUI_Clienti extends JFrame implements DocumentListener,MouseListener {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel panel=new JPanel();
	JTextArea textArea=new JTextArea();
	JButton add=new JButton("Add");
	JButton remove=new JButton("Remove");
	JButton edit=new JButton("Edit");
	JButton extras_cont=new JButton("Extras de cont");
	JLabel label=new JLabel("Enter cnp to search:");
	JTextField entry=new JTextField(10);
	final static Color  HILIT_COLOR = Color.lightGray;
	final static Color  ERROR_COLOR = Color.PINK;
	final static String CANCEL_ACTION = "cancel-search";
	    
	final Color entryBg;
	final Highlighter hilit;
	final Highlighter.HighlightPainter painter;
	 private JLabel status=new JLabel();
	 Bank bank;
	 
	 Action selectLine;
	 
	 
	 
	 /**
	  * constructor de initializare
	  */
	public GUI_Clienti(){
		
	addComponents();
	
	bank=new Bank();
	bank.populate("clienti.txt");
	
	citesteFisier();
    
    hilit = new DefaultHighlighter();
    painter = new DefaultHighlighter.DefaultHighlightPainter(HILIT_COLOR);
    textArea.setHighlighter(hilit);
    
    entryBg = entry.getBackground();
    entry.getDocument().addDocumentListener(this);
    
    InputMap im = entry.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    ActionMap am = entry.getActionMap();
    im.put(KeyStroke.getKeyStroke("ESCAPE"), CANCEL_ACTION);
    am.put(CANCEL_ACTION, new CancelAction());
		
	}
	
	/**
	 * se creeaza ferestra principala a proiectului
	 */
	
	public void addComponents(){
		
		panel.add(label);
		panel.add(entry);
		panel.add(createTextArea());
		panel.add(status);
		panel.add(add);
		panel.add(remove);
		panel.add(edit);
		panel.add(extras_cont);
		
		remove.setEnabled(false);
		edit.setEnabled(false);
		extras_cont.setEnabled(false);
		
		
		remove.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				System.out.print("remove");
	              
	              int n =JOptionPane.showConfirmDialog(panel,
	                       "Are you sure?","Remove",
	                       JOptionPane.YES_NO_OPTION);
	              
                if (n == JOptionPane.YES_OPTION) {
                    //sterge clientul din fisier si din hashtable si implicit contul acestuia
              	  System.out.println("Sterge clinetul si contul lui!");
              	  bank.removeClient(getClient(textArea.getSelectedText()), "clienti.txt");
              	  textArea.setText("");
              	  citesteFisier();
              	  
                } 

	         
	           }	
			
		});
		
		
		edit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				System.out.println("edit");
	             System.out.println(textArea.getSelectedText());
	             
	             String cod=textArea.getSelectedText().substring(0, 13);
	             
	             System.out.println("cnp="+cod);	             
	             Account cont1=(Account) bank.getValues(cod).get(0);
	               GUI_Edit x=new GUI_Edit(cod+".txt",cont1,bank);
	               
	               class listenerSave implements ActionListener{

	    				public void actionPerformed(ActionEvent arg0) {
	    					
	    					textArea.setText("");
	    					citesteFisier();
	    					
	    				}
	    				
	    			}
	    		 
	    		 x.addListenerSave(new listenerSave());
	            }
				
			
		});
		
		extras_cont.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				System.out.println("extras de cont");
	               new Gui_extras(bank,getClient(textArea.getSelectedText()));
				
			}
		});
		
		 add.addMouseListener(new java.awt.event.MouseAdapter() {
	            public void mousePressed(java.awt.event.MouseEvent evt) {
	            	       	
	               System.out.println("add");
	               final GUI_ADD x= new GUI_ADD(bank);
	                
	                class listenerSave implements ActionListener{

	    				@Override
	    				public void actionPerformed(ActionEvent arg0) {
	    					// TODO Auto-generated method stub
	    					
	    					if (x.getVerificat()==true){
	    						
	    						textArea.setText("");
	    						citesteFisier();
	    						
	    					}
	    					
	    					
	    				}
	    				
	    			}
	    		 
	    		 x.addListenerSave(new listenerSave());
	            }
	               
	               
	            

	           
			});
		 
		
		 
		
		this.add(panel);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setTitle("Bank_Simulation");

		this.pack();
		this.setSize(550,400);
		this.setVisible(true);
		this.setLocation(500, 200);
		this.setLayout(new BorderLayout());
		
	}
	
	/**
	 * 
	 * @return un jscrollpane care contine un textarea care contine datele personale ale clientilor bancii
	 */
	
	public JScrollPane createTextArea(){	
		
		textArea=new JTextArea();
		textArea.setEditable(false);
	    textArea.setBackground(Color.WHITE);
	    textArea.addMouseListener(this);
	    selectLine = getAction(DefaultEditorKit.selectLineAction);
	    JScrollPane scrollPane = new JScrollPane(textArea); 
	    scrollPane.setPreferredSize(new Dimension(500,300));
	    
	    return scrollPane;
	}
	
	/**
	 * cauta textul introdus de utilizator in casuta respectiva si il anunta pe acesta
	 * daca textul cautat a fost sau nu gasit prin subliniarea cuvantului cautat in tabela cu clienti,
	 * respectiv afisarea unui mesaj de avertizare conform caruia textul cautat nu exista
	 */
	
	public void search() {
        hilit.removeAllHighlights();
        
        String s = entry.getText();
        if (s.length() <= 0) {
            message("Nothing to search");
            return;
        }
        
        String content = textArea.getText();
        int index = content.indexOf(s, 0);
        if (index >= 0) {   // match found
            try {
                int end = index + s.length();
                hilit.addHighlight(index, end, painter);
                textArea.setCaretPosition(end);
                entry.setBackground(entryBg);
                message("'" + s + "' found. Press ESC to end search");
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        } else {
            entry.setBackground(ERROR_COLOR);
            message("'" + s + "' not found. Press ESC to start a new search");
        }
    }
	
	/**
	 * 
	 * @param msg- mesajul care va fi afisat cand se va cauta un cuvant
	 */

	 void message(String msg) {
	        status.setText(msg);
	    }

	    // DocumentListener methods
	    
	    public void insertUpdate(DocumentEvent ev) {
	        search();
	    }
	    
	    public void removeUpdate(DocumentEvent ev) {
	        search();
	    }
	    
	    public void changedUpdate(DocumentEvent ev) {
	    }
	    
	    class CancelAction extends AbstractAction {
	        /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent ev) {
	            hilit.removeAllHighlights();
	            entry.setText("");
	            entry.setBackground(entryBg);
	        }
	    }	
	    
	    /**
	     * 
	     * @param name
	     * @return un obicet de tipul action
	     */
	
	    private Action getAction(String name)
	    {
	        Action action = null;
	        Action[] actions = textArea.getActions();
	  
	        for (int i = 0; i < actions.length; i++)
	        {
	            if (name.equals( actions[i].getValue(Action.NAME).toString() ) )
	            {
	                action = actions[i];
	                break;
	            }
	        }
	  
	        return action;
	    }
	  
	    
	    /**
	     * se intercepteaza click-urile de mouse si in functie de acestea se efectueaza anumite actiuni
	     */
	    public void mouseClicked(MouseEvent e)
	    {
	  
	        if ( SwingUtilities.isLeftMouseButton(e) && textArea.getSelectedText()!="")
	        {
			selectLine.actionPerformed(null);
			 System.out.println("ai selectat o linie");
			 
			 remove.setEnabled(true);
			 edit.setEnabled(true);
			 extras_cont.setEnabled(true);
	        }   
	       
	  
	        System.out.println(textArea.getSelectedText());
	    
	  
	        }
	    
	    
	    
	  
	    public void mousePressed(MouseEvent e) {}
	    public void mouseReleased(MouseEvent e) {}
	    public void mouseEntered(MouseEvent e) {}
	    public void mouseExited(MouseEvent e) {}
	  
	
	 /**
	  *    returneaza un obiect de tipul Person, ale carui date de initializare sunt preluate din linia selectata de 
	  *    utilizator
	  * @param sir - linia selectata de utilizator
	  * @return -un obiect de tipul Person
	  */
	public Person getClient(String sir){
		String cnp="";
		String nume="";
		String prenume="";
		String adresa="";
		String nr_tel="";
		
		

		StringTokenizer st = new StringTokenizer(sir,"	");
		 
		System.out.println("---- Split by tab ------");
		while (st.hasMoreElements()) {
		//	System.out.println(st.nextElement());
			 cnp=st.nextElement().toString();
			
			StringTokenizer st1=new StringTokenizer(st.nextElement().toString());
			while (st1.hasMoreElements()){
				nume=st1.nextElement().toString();
				prenume=st1.nextElement().toString();
			}
			
			adresa=st.nextElement().toString();
			nr_tel=st.nextElement().toString();
			
		
	}
		return new Person(cnp, nume, prenume, adresa, nr_tel);
	}
	
	/**
	 * citeste din fisier clientii bancii si ii adauga in textarea
	 */
	
	public void citesteFisier(){

		BufferedReader br=null;
	    try {
	    	br=new BufferedReader(new FileReader("clienti.txt"));
	        textArea.read(br, null);
	        br.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	}


