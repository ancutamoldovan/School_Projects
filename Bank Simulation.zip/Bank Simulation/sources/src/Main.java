/**
 * clasa Main creeaza un obiect de tipul GUI_Clienti care lanseaza in executie fereastra principala a proiectului
 * @author Moldovan Ancuta
 *
 */
public class Main {

	public static void main(String[] args){
		
			
			new GUI_Clienti();
		
	    }
		
}
