import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 * Clasa Gui_addAccount reprezinta fereastra pe care utilizatorul o foloseste pentru a adauga un nou cont unui client
 * un obiect de tipul Gui_addAccount este caracterizat de banca de care apartine clientul si de clientul caruia i se va
 * adauga noul cont creat
 * @author Moldovan Ancuta
 *
 */

public class Gui_addAccount {

	JFrame f=new JFrame();
	JPanel panel;
	JTextField Nr_cont;
	JButton ok;
	Person client;
	Bank bank;
	boolean verificat;
	
	/**
	 * Constructor de initializare
	 * @param bank - banca de care apartine clientul
	 * @param client - clientul caruia i se va adauga noul cont
	 */
	
	public Gui_addAccount(Bank bank,Person client){
		this.client=client;
		this.bank=bank;
		addComponents();
	}
	
	/**
	 * creaza fereastra pentru adaugarea contului
	 */
	
	public void addComponents(){
		
		f.add(createPanel());
		
		f.setTitle("add");
		f.pack();
		f.setSize(300,100);
		f.setVisible(true);
		f.setLocation(500, 200);
		f.setLayout(new BorderLayout());
		
		
	}
	/**
	 * creaza un panou care va contine elementele necesare pentru adaugarea unui nou cont unui client al bancii
	 * @return un panou care va contine elementele necesare adaugarii unui cont
	 */
	
	public JPanel createPanel(){

		panel=new JPanel();
		Nr_cont=new JTextField(10);
		ok=new JButton("OK");
		JLabel nr_cont=new JLabel("Nr_cont:");
		
		panel.add(nr_cont);
		panel.add(Nr_cont);
		panel.add(ok);
		
		ok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
            	       	
               System.out.print("save new account");
               if (verificaCont(Nr_cont.getText())==false)
           		JOptionPane.showMessageDialog(panel,
                           "Asigurati-va ca ati introdus corect datele",
                           "Eroare",
                           JOptionPane.ERROR_MESSAGE);
               else{
            	   saveNewAccount();
            	   verificat=true;
            	   f.setVisible(false);
            	   
            	  
               }
               
        
            

         
           }
		});
		
		return panel;
	}
	
	/**
	 * salveaza noul cont al clientului 
	 */
	
	public void saveNewAccount(){
		
		bank.addAccount(client.getCnp(), new Account(Nr_cont.getText(),client,0));
		bank.writeAccount(client.getCnp()+".txt",new Account(Nr_cont.getText(),client,0));
		System.out.println(contToString());
		
	}
	
	/**
	 * returneaza numarul contului adaugat
	 * @return numarul contului adaugat
	 */
	
	public String contToString(){
		return Nr_cont.getText()+"\t"+0.0;
	}
	
	/**
	 * 
	 * @param x - actionlistener necesar pentru sincronizarea cu fereastra care va crea un obiect de tipul Gui_addAccount
	 */
	
	public void addListenerOk(ActionListener x){
	 ok.addActionListener(x);
	}
	

	/**
	 * returneaza true daca s-a apasat butonul ok, si false in caz contrar
	 * @return un rezultat de tip boolean,care indica apasarea sau nu a butonului ok
	 */
	
	public boolean getVerificat(){
		return verificat;
	}
	/**
	 * verifica contul introdus
	 * @param cont - numarul contului pe care vrem sa l adaugam
	 * @return true sau false, in functie de corectitudinea contului introdus
	 */
	public boolean verificaCont(String cont){
		boolean rezultat=true;
		
		if ((cont.length()!=11) || (bank.cautaNrCont(cont)!=null)) rezultat=false;
		
		System.out.println("verificare:"+rezultat);
		
		return rezultat;
	}
	
	
	
	

}
