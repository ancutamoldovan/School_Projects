package institutie;

import java.io.Serializable;

/**
 * clasa necesara pentru cautarea trenurilor
 * contine obiecte de tip Interval, compuse din 2 obiecte de tip Ceas
 * @author Moldovan Ancuta
 *
 */
public class Interval implements Serializable {
	
	private Ceas plecare;
	private Ceas sosire;
	/**
	 * 
	 * @param plecare - statia din care se pleaca
	 * @param sosire - statia in care se ajunge (destinatia)
	 */
	public Interval(Ceas plecare,Ceas sosire){
		
		this.plecare=plecare;
		this.sosire=sosire;
		
	}
	/**
	 * functie care returneaza un obiect de tip Ceas care reprezinta ora ajungerii intr-o statie
	 * @return un obiect de tip Ceas
	 */
	public Ceas getPlecare(){
		return plecare;
	}
	
	/**
	 * functie care returneaza un obiect de tip Ceas care reprezinta ora ajungerii la destinatie
	 * @return un obiect de tip Ceas
	 */
	public Ceas getSosire(){
		return sosire;
	}
	
}
