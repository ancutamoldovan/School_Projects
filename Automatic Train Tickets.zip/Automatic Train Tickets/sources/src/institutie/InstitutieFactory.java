package institutie;

/**
 * clasa care creaza obiecte de tip Institutie
 * @author Moldovan Ancuta
 *
 */
public class InstitutieFactory {
	/**
	 * functie care returneaza o instanta a obiectului transmis ca si parametru
	 * @param criteria - obiectul a carui instanta trebuie creata
	 * @return un obiect de tip Institutie
	 */
	 public static Institutie getInstitutie(String criteria)
	  {
	    if ( criteria.equals("banca") )
	      return Bank.getInstance();
	    else if ( criteria.equals("gara") )
	      return Tren.getInstance();
	    else if (criteria.equals("infoTren"))
	    	return InfTren.getInstance();


	    return null;
	  }
}

