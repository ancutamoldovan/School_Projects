package institutie;
import java.io.Serializable;

/**
 * clasa Person defineste un obiect de tipul Person
 * un obiect de tipul Person este caracterizat de cnp,nume,prenume,adresa si numarul de telefon
 * @author Moldovan Ancuta
 *
 */
public class Person implements Serializable {
	
	public String cnp,nume,prenume,adresa,nr_tel;
	
	/**
	 * Constructor de initializare
	 * @param cnp - cnp-ul clientului
	 * @param nume - numele clientului
	 * @param prenume - prenumele clientului
	 * @param adresa - adresa clientului 
	 * @param nr_tel - numarul de telefn al clientului
	 */
	
	public Person(String cnp,String nume,String prenume,String adresa,String nr_tel){
		this.cnp=cnp;
		this.nume=nume;
		this.prenume=prenume;
		this.adresa=adresa;
		this.nr_tel=nr_tel;
	}
	
	/**
	 * returneaza cnp-ul clientului
	 * @return cnp-ul clientului
	 */
	
	public String getCnp(){
		return cnp;
	}
	
	/**
	 * returneaza numele clientului
	 * @return numele clientului
	 */
	public String getNume(){
		return nume;
	}
	
	/**
	 * returneaza prenumele clientului
	 * @return penumele clientului
	 */
	
	public String getPrenume(){
		return prenume;
	}
	
	/**
	 * returneaza adresa clientului
	 * @return adresa clientului
	 */
	
	public String getAdresa(){
		return adresa;
	}
	
	/**
	 * returneaza numarul de telefon al clientului
	 * @return numarul de telefon al clientului
	 */
	public String getNrTel(){
		return nr_tel;
	}
	
	/**
	 * returneaza datele personale ale clientului
	 */
	
	public String toString(){
		return cnp+"\t"+nume+" "+prenume+"\t"+adresa+"\t"+nr_tel;
	}
	
	/**
	 * 
	 * @return un obiect de tipul Person
	 */
	public Person getPerson(){
		return this;
	}

}
