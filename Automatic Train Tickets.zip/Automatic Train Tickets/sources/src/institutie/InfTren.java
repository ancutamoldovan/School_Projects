package institutie;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.TreeMap;

/**
 * clasa care contine informatii referitoare la numerele trenurilor si locurile disponibile din acestea
 * @author Moldovan Ancuta
 *
 */
public class InfTren implements Institutie{
	
	
	Hashtable<String,ArrayList<Boolean>> info=new Hashtable<String,ArrayList<Boolean>>();
	
	private static InfTren instance=null; 

	
	private InfTren(){};
	
	/**
	 * functie care returneaza o instanta a obiectului de tip InfTren (patternul Singleton)
	 * @return un obiect de tip tren
	 */
	public static InfTren getInstance() {
		if (instance == null)
			instance =new InfTren();
		return instance;
	}
	
	/**
	 * functie stabileste unui anumit tren un anumit numar de locuri
	 * @param nr_tren - numarul trenului la care se adauga ruta
	 * @param nr_locuri - numarul de locuri disponibile
	 * @pre (nr_tren.compareTo("")!=0);
	 * @post
	 */
	public void adaugaInf(String nr_tren,int nr_locuri)
	{
		
		assert (nr_tren.compareTo("")!=0);
		
		System.out.println("cheia cu nr "+ nr_tren+info.containsKey(nr_tren)+" momentan");
		if (!info.containsKey(nr_tren)){
		
			
			ArrayList<Boolean> locuri = info.get(nr_tren);
			if (locuri == null) {
				locuri = new ArrayList<Boolean>();
				for (int i=0;i<nr_locuri;i++)
					locuri.add(true);
			}
			
			
			System.out.println("locuri="+locuri.size());
			
			info.put(nr_tren,locuri);
		}
		
	}
	
	/**
	 * functie care sterge informatile disponibile despre tren
	 * @param nr_tren - numarul trenului din care se sterge informatia
	 * @pre (info.get(nr_tren) != null);
	 * @post 
	 */
	
	public void stergeInf(String nr_tren){
		
		assert (info.get(nr_tren) != null);
		
		info.remove(nr_tren);
	}
	/**
	 * 
	 * @return tabelul cu informatiile despre trenuri
	 * @pre info!=null
	 * @post nochange
	 */
	public Hashtable<String, ArrayList<Boolean>> hash (){
		assert info!=null;
		
		return info;
	}
	
	/**
	 * functie care retunreaza situatia locurilor(disponibile si indisponibile) dintr un anumite tren
	 * @param nr_tren - numarul trenului 
	 * @return situatia locurilor
	 * @pre 
	 * @post nochange
	 */
	public ArrayList<Boolean> situatieLocuri(String nr_tren){
		
		assert (info.containsKey(nr_tren)==true);
			
			return info.get(nr_tren);
	}
	
	/**
	 * functie care returneaza numarul de locuri din trenul respectiv
	 * @param nr_tren - numarul trenului
	 * @return - numarul de locuri
	 * @pre (info.get(nr_tren)!=null);
	 * @post nochange
	 */
	
	public int getNrLocuri(String nr_tren){
		assert (info.get(nr_tren)!=null);
		
		return info.get(nr_tren).size();
	}
	
	
	/**
	 * functie pentru serializarea obiectuli de tip InfTren
	 * @pre true
	 * @post nochange
	 */
	public void salvare() {
		
		try { 
			
			FileOutputStream fos = new FileOutputStream("info_trenuri.bin"); 
			ObjectOutputStream oos = new ObjectOutputStream(fos); 
			oos.writeObject(info); 
			oos.flush(); 
			oos.close(); 
			} 
			catch(Exception e) { 
			System.out.println("Exception during serialization: " + e); 
			System.exit(0); 
			} 
		
		
	}
		/**
		 * functie pentru deserializarea obiectului de tip InfTren
		 * @pre true
		 * @post nochange
		 */
		public void incarcare() {
			
			
			try { 
				FileInputStream fis = new FileInputStream("info_trenuri.bin"); 
				ObjectInputStream ois = new ObjectInputStream(fis); 
				info =(Hashtable<String, ArrayList<Boolean>>) ois.readObject(); 
				ois.close();
				
				} 
				catch(Exception e) { 
				System.out.println("Exception during deserialization: " + e.getMessage()); 
				System.exit(0); 
				} 
		
			
		}
		
	
	
	
	

}
