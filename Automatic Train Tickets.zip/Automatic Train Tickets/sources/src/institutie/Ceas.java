package institutie;
import java.io.Serializable;

/**
 * clasa Ceas contine obiecte de forma hh:mm:ss si operatiile care se pot efectua asupra acestora
 * @author Moldovan Ancuta
 *
 */
public class Ceas implements Serializable{
	

	private int o,m,s;
	/**
	 * constructor ptr cazul in care se cunoaste nr de ore,min si sec
	 * @param ora - ora 
	 * @param min - minutul
	 * @param sec - secunda
	 */
	
	public Ceas(int ora,int min,int sec){
		o=ora;
		m=min;
		s=sec;
		if (s>59) {
			m=m+1;
			s=s%60;
		}
		
		if (m>59){
			o=o+1;
			m=m%60;
		}
				
	}
	
	/**
	 * constructor ptr cazul in care ora este data sub forma unui sir de caractere
	 * @param sir - sir de forma hh:mm:ss
	 */
	//constructor ptr cazul in care ora este data sub forma unui sir de caractere
	
	public Ceas(String sir){
		o=Integer.parseInt(sir.substring(0, 2));
		m=Integer.parseInt(sir.substring(3, 5));
		s=Integer.parseInt(sir.substring(6));
	}
	
	/**
	 * 
	 * @return numarul de ore
	 */
	public int nr_ore(){
		return o;
	}
	
	/**
	 * 
	 * @return numarul de minute
	 */
	public int nr_min(){
		return m;
	}
	
	/**
	 * 
	 * @return numarul de secunde
	 */
	public int nr_sec(){
		return s;
	}
	
	/**
	 * functie care calculeaza diferenta dintre doi timpi in secunde
	 * @param c1 - prima ora
	 * @param c2 - ce a de a doua ora
	 * @return diferenta dintre doi timpi in secunde
	 */
	public int diferenta_ceas_secunde(Ceas c1,Ceas c2){//returneaza diferenta dintre doi timpi in secunde
		return 3600*(c1.o-c2.o)+60*(c1.m-c2.m)+(c1.s-c2.s);
		
	}
	
	/**
	 * 
	 * @param c1 - prima ora
	 * @param c2 - ce a de a doua ora
	 * @return un obiect de tip Ceas reprezentand diferenta a doi timpi in secunde
	 */
	
	public Ceas diferenta_ceas(Ceas c1,Ceas c2){//returneaza diferenta dintre doi timpi in secunde
		int sec,min,ora;
		sec=3600*(c1.o-c2.o)+60*(c1.m-c2.m)+(c1.s-c2.s);
		if (sec>=3600) {
			ora=sec/3600;
			sec=sec%3600;
			if (sec>=60){
				min=sec/60;
				sec=sec%60;
			}
			else min=0;
		}
		else {
			ora=0;
			if (sec>=60){
				min=sec/60;
				sec=sec%60;
			}
			else min=0;
		}
		
		Ceas cesulet=new Ceas(ora,min,sec);
		return cesulet;
		
	}
	/**
	 * functie care calculeaza suma a doi timpi in secunde; folosita pentru aflarea timpului de plecare sau asteptare
	 * @param c1 - prima ora
	 * @param c2 - ce a de a doua ora
	 * @return un obiect de tip ceas 
	 */
	public Ceas suma_ceas(Ceas c1,Ceas c2){//returneaza suma a doi timpi in secunde; folosita pentru aflarea timpului de plecare sau asteptare
		int sec,min,ora;
		sec=3600*(c1.o+c2.o)+60*(c1.m+c2.m)+c1.s+c2.s;
		if (sec>=3600) {
			ora=sec/3600;
			sec=sec%3600;
			if (sec>=60){
				min=sec/60;
				sec=sec%60;
			}
			else min=0;
		}
		else {
			ora=0;
			if (sec>=60){
				min=sec/60;
				sec=sec%60;
			}
			else min=0;
		}
		
		Ceas cesulet=new Ceas(ora,min,sec);
		return cesulet;
	}
	
	
	/**
	 * functie care transpune ceasul sub forma unui sir de caractre
	 * @return reprezentarea ceasului sub forma unui sir de caractere
	 */
	public String ceas_string(){
		String sub;
		if (o<10) sub="0"+o;
		else sub=""+o;
		if (m<10) sub=sub+":"+"0"+m;
		else sub=sub+":"+m;
		if (s<10) sub=sub+":"+"0"+s;
		else sub=sub+":"+s;
		return sub;
	}
	
	/**
	 * returneaza timpul in minute
	 * @param c - ceasul
	 * @return timpul in minute
	 */
	
	public int return_minute(Ceas c){//returneaza timpul in minute
		return 60*c.nr_ore()+c.nr_min()+c.nr_sec()/60;
		
	}
	
	/**
	 * returneaza timpul in secunde
	 * @param c - ceasul
	 * @return timpul in secunde
	 */
	
	public int return_secunde(Ceas c){//returneaza timpul in secunde
		return 3600*c.nr_ore()+60*c.nr_min()+c.nr_sec();
		
	}
}

