package institutie;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * clasa Tren reprezinta de fapt o gara si contine toate trenurile din aceasta impreuna cu rutele sale
 * @author Moldovan Ancuta
 *
 */
public class Tren implements Institutie {


	
	Institutie info=InstitutieFactory.getInstitutie("infoTren");
	TreeMap<String,ArrayList<Ruta>> tren=new TreeMap<String,ArrayList<Ruta>>();
	private static Tren instance=null; 
	
	private Tren(){}
	/**
	 * functie care returneaza o instanta a obiectului de tip Tren (patternul Singleton)
	 * @return un obiect de tip tren
	 */
	public static Tren getInstance() {
		if (instance == null)
			instance =new Tren();
		return instance;
	}
	/**
	 * functie care adauga o ruta unui tren deja existent sau creeaza un nou tren
	 * @param nr_tren - numarul trenului la care se adauga ruta
	 * @param nr_locuri - numarul de locuri pentru trenul respectiv
	 * @param ruta - ruta care sa adauga trenului
	 * @pre nr_tren.compareTo("")!=0;
	 * @post 
	 */
	public void adaugaRuta(String nr_tren,int nr_locuri, Ruta ruta)
	{
	
		assert (nr_tren.compareTo("")!=0);
		((InfTren) info).adaugaInf(nr_tren, nr_locuri);
		ArrayList<Ruta> Rute = tren.get(nr_tren);
		if (Rute == null) {
			Rute = new ArrayList<Ruta>();
		}
		if (!Rute.contains(ruta)) {
			Rute.add(ruta);
			tren.put(nr_tren,Rute);
		}
		
		salvare();
	}
	/**
	 * functie care sterge o ruta a unui tren
	 * @param nr_tren - numarul trenului de la care se sterge ruta
	 * @param ruta - ruta care se doreste a fi stearsa
	 * @pre tren.get(nr_tren) != null && tren.get(nr_tren).contains(ruta));
	 * @post 
	 */
	public void stergeRuta(String nr_tren,Ruta ruta){
		
		assert (tren.get(nr_tren) != null && tren.get(nr_tren).contains(ruta));
		
		tren.get(nr_tren).remove(ruta);
		salvare();
		
	}
	
	/**
	 * functie care sterge o un tren, impreuna cu toate rutele sale
	 * @param nr_tren - numarul trenului care se doreste a fi sters
	 * @pre (tren.get(nr_tren) != null)
	 * @post 
	 */
	public void stergeTren(String nr_tren){
		
		assert (tren.get(nr_tren) != null);
		
		((InfTren) info).stergeInf(nr_tren);
		tren.remove(nr_tren);
		salvare();
		
		}
	
	/**
	 * functie pentru serializarea obiectului de tip Tren
	 * @pre true
	 * @post nochange
	 */
	public void salvare() {
			
	try { 
		
		info.salvare();
		
		FileOutputStream fos = new FileOutputStream("trenuri.bin"); 
		ObjectOutputStream oos = new ObjectOutputStream(fos); 
		oos.writeObject(tren); 
		oos.flush(); 
		oos.close(); 
		} 
		catch(Exception e) { 
		System.out.println("Exception during serialization: " + e); 
		System.exit(0); 
		} 
	
	
}
	/**
	 * functie pentru deserializarea obiectului de tip Tren
	 * @pre true
	 * @post nochange
	 */
	public void incarcare() {
		
		
		try { 
			info.incarcare();
			FileInputStream fis = new FileInputStream("trenuri.bin"); 
			ObjectInputStream ois = new ObjectInputStream(fis); 
			tren =(TreeMap<String, ArrayList<Ruta>>) ois.readObject(); 
			ois.close();
			
			} 
			catch(Exception e) { 
			System.out.println("Exception during deserialization: " + e.getMessage()); 
			System.exit(0); 
			} 
	
		
	}
	/**
	 * functie care returneaza toate rutele existente alea trenului
	 * @param nr_tren - numarul trenului 
	 * @return toate rutele trenului repsectiv
	 * @pre tren.get(nr_tren)!=null
	 * @post nochange
	 */
	public String veziRuteString(String nr_tren) {
		
		assert (tren.get(nr_tren)!=null);
		String detalii = null;
		for (Ruta r : tren.get(nr_tren)){
			if (detalii==null)
				detalii=nr_tren+":";
			detalii=detalii+r.getNumeRuta()+"->";
		}
		
		
		return detalii;
		
	}
	/**
	 * functie care returneaza un vector ce contine toate rutele trenului respectiv
	 * @param nr_tren - numarul trenului
	 * @return rutele trenului
	 * @pre tren.get(nr_tren)!=null
	 * @post nochange
	 */
	public ArrayList<Ruta> veziRute(String nr_tren){
		
		assert (tren.get(nr_tren)!=null);
		
		return tren.get(nr_tren);
	}
		
	/**
	 * functie care returneaza toate trenurile care exista in gara respectiva
	 * @return sir ca contine toate trenurile
	 * @pre tren!=null;
	 * @post nochange
	 */
	public String veziTrenuri(){
		
		assert (tren!=null);
		
		String rezultat="";
		Set<?> set = tren.entrySet();
		Iterator<?> i = set.iterator();  
		while(i.hasNext()) { 
		Map.Entry me = (Map.Entry)i.next(); 
		rezultat=rezultat+veziRuteString(me.getKey().toString())+"\n";
		} 
		return rezultat;
	}
	
	
	/**
	 * functie care cauta trenuri ale caror rute indeplinesc conditiile cerute
	 * @param plecare - statia din care se pleaca
	 * @param sosire - statia in care se ajunge (destinatie)
	 * @param p - intervalul in care se ajunge in statie
	 * @param s - intervalul in care se ajunge la destinatie
	 * @return toate rutele care indeplinesc conditiile date
	 * @pre tren!=null
	 * @post nochange
	 */
	public String cautaTrenuri(String plecare,String sosire, Interval p,Interval s){
		
		
		assert (tren!=null);
		
		boolean gasit1=false,gasit2=false;
		String rezultate=null;
	
		
		for (String trenulet : tren.keySet()) {
			for (Ruta r : tren.get(trenulet)) {
			
				if (r.getNumeRuta().compareTo(plecare)==0){
					System.out.println(r.getNumeRuta());
					if (p.getPlecare().return_secunde(p.getPlecare())<=r.getPlecare().return_secunde(r.getPlecare())){
						
						if (r.getPlecare().return_secunde(r.getPlecare())<=p.getSosire().return_secunde(p.getSosire())){
							System.out.println("prima conditie indeplinita :)");
							gasit1=true;
						}
							
					}
						
				}
					
				
						
				if (gasit1==true)
						if (r.getNumeRuta().compareTo(sosire)==0){
							System.out.println(r.getNumeRuta());
							if (s.getPlecare().return_secunde(s.getPlecare())<=r.getSosire().return_secunde(r.getSosire())){
								
								System.out.println("pana aici merge");
								
								if (r.getSosire().return_secunde(r.getSosire())<=s.getSosire().return_secunde(s.getSosire())){
									System.out.println("a doua conditie indeplinita :)");
									gasit2=true;
								}
									
							}
								
						}
				
				System.out.println("gasit1="+gasit1+" gasit2="+gasit2);
							
				if ((gasit1==true)&&(gasit2==true))
					if (rezultate==null){
						System.out.println("bau");
						rezultate=""+veziRuteString(trenulet)+"\n";
					}
						
					else {
						System.out.println("bau2");
						rezultate=rezultate+veziRuteString(trenulet)+"\n";
					}
				
				else System.out.println("nu exista trenuri");
					
					
					
				
		}
			
			gasit1=false;
			gasit2=false;

	}
	
		return rezultate;
}
	/**
	 * functie care returneaza tabela care contine informatii
	 * @return un obiect de tip Institutie
	 * @pre info!=null
	 * @post nochange
	 */
	public Institutie getInfo(){
		assert (info!=null);
		
		return info;
	}
	
	
}