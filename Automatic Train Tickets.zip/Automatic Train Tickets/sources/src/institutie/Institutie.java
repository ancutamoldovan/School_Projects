package institutie;

public interface Institutie {
	
	/**
	 * functie pentru deserializarea obiectelor 
	 */
	public void incarcare();
	/**
	 * functie pentru serializarea obiectelor
	 */
	public void salvare();

}
