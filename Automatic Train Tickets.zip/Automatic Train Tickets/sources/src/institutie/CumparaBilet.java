package institutie;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 * clasa necesara achizitionarii unui bilet de catre calator
 * @author Moldovan Ancuta
 *
 */
public class CumparaBilet {
	
	private Institutie bank;
	private String nr_tren;
	private String plecare;
	private String destinatie;
	private Institutie tren;
	private Account cont;
	private String nr_cont;
	private String nr_legitimatie;
	private Institutie info; 
	int optiune_pret;//0-bilet intreg, 1-bilet reducere
	int optiune_bilet;//0-dus, 1-dus-intors
	double pret;
	int nr_loc;
	private ArrayList<Boolean> locuri;
	int i1,i2;//locul in vectorul de rute in care se gaseste plecarea, respectiv destinatia
	int durata;//durata in secunde a timpului in care se ajunge de la plecare la destinatie
	ArrayList<Ruta> rute;

	/**
	 * constructor de intializaare
	 * @param bank2 - banca care contine conturile
	 * @param nr_cont - numarul contului din care se extrage suma de bani
	 * @param nr_legitimatie - numarul legitimatiei
	 * @param tren2 - gara
	 * @param nr_tren - numarul trenului cu care doreste sa se circule
	 * @param plecare - statia din care se pleaca
	 * @param destinatie - destinatia
	 * @param optiune_pret - 0 bilet intreg 1 bilet redus
	 * @param optiune_bilet - 0 dus 1 dus-intors
	 */
	public CumparaBilet(Institutie bank2,String nr_cont,String nr_legitimatie,Institutie tren2,String nr_tren,String plecare,String destinatie,int optiune_pret,int optiune_bilet){
		
		this.bank=bank2;
		this.nr_tren=nr_tren;
		this.plecare=plecare;
		this.destinatie=destinatie;
		this.nr_cont=nr_cont;
		this.optiune_pret=optiune_pret;
		this.optiune_bilet=optiune_bilet;
		this.tren=tren2;
		this.nr_legitimatie=nr_legitimatie;
		cumpara();
		
	}
	
	/**
	 * Functie care calculeaza pretul final al biletului
	 * @return pretul final al biletului
	 */
	public double getPret(){
		
	 pret=veziPret();
		if ((optiune_pret==0))
				if (optiune_bilet==0)
					return pret;
				else return 2*pret-2*pret*20/100;
		else if (optiune_bilet==0)
			return pret-pret*50/100;
		else return 2*pret-2*pret*20/100;
	}
	
	/**
	 * Functie care returmneaza statia din care se pleaca
	 * @return statia din care se pleaca
	 */
	
	public String getPlecare(){
		return plecare;
	}
	
	/**
	 * Functie care returneaza destinatia 
	 * @return destinatia
	 */
	
	public String getDestinatie(){
		return destinatie;
	}
	
	/**
	 * functie care se ocupa de vanzarea biletului, trecand prin toate etapele si anume:
	 * generare loc, retragere suma de bani din cont,eliberarea biletului
	 */
	public void cumpara(){
		genereazaLoc();
		cont=((Bank) bank).cautaNrCont(nr_cont);
		cont.spendingMoney(getPret());
		bank.salvare();
		printeazaBilet();
	}
	/**
	 * functie care se ocupa de printarea biletului, si anume de printarea tuturor detaliilor calatoriei
	 */
	public void printeazaBilet(){
		FileWriter f;
		try {
			f = new FileWriter("bilet.txt");
			BufferedWriter out=new BufferedWriter(f);
			
			if (optiune_pret==1){
				out.write("Bilet reducere "+"Categorie:Elev/Student/Pensionar"+"\tLeg."+nr_legitimatie);
				out.newLine();
			}
			else {
				out.write("Bilet intreg");
				out.newLine();
			}
			
			if (optiune_bilet==0)
			{
				out.write("Bilet dus");
				out.newLine();
			}
			
			else {
				out.write("Bilet dus-intors");
				out.newLine();
			}
			
			
			out.write("Plecare:"+plecare+"\t"+rute.get(i1).getPlecare().ceas_string());
			out.newLine();
			out.write("Sosire:"+destinatie+"\t"+rute.get(i2).getSosire().ceas_string());
			out.newLine();
			out.write("Lei**********"+getPret());
			out.newLine();
			out.write("Data:"+new Date()+"\tTren:"+nr_tren);
			out.newLine();
			out.write("Numar loc:"+nr_loc+"\t");
			out.newLine();
			out.write("Calatoriti cu CFR Calatori");
			
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * calculeaza pretul dintre 2 statii selectate de clien
	 * @return pretul dintre plecare si destinatie
	 */
	
	private double veziPret(){
		rute=((Tren) tren).veziRute(nr_tren);
		double pret_bilet=0;
		//int i1 = 0,i2 = 0;//indecsii la care se gasesc plecarea, respectiv destinatia
		
		for(int i=0;i<rute.size();i++){
			if (rute.get(i).getNumeRuta().compareTo(plecare)==0)
				i1=i;
			if (rute.get(i).getNumeRuta().compareTo(destinatie)==0)
				i2=i;

		}
		
		for(int i=i1;i<i2;i++)
			pret_bilet=pret_bilet+rute.get(i).getPret();
		return pret_bilet;
	}
	/**
	 * functie care genereaza un loc random intre cele puse la dispozitie
	 */
	private void genereazaLoc(){
		
		double pret_proba=veziPret();
		//info=(InfTren)tren.info;
		info=((Tren) tren).getInfo();
		int min = 1;
		int max = ((InfTren) info).getNrLocuri(nr_tren);

		//generam un numar random care sa fie cuprins intre 1 si numarul total de locuri
		Random rand = new Random();
		nr_loc= rand.nextInt(max - min + 1) + min;
		
		locuri=((InfTren) info).situatieLocuri(nr_tren);
		//setam locul respectiv pe false(ocupat)
		System.out.println("loc blocat");
		locuri.set(nr_loc-1,false);
		//deblocam locul in momentul in care trenul a ajuns la destinatie
		Timer timer=new Timer();
		System.out.println("i1="+i1+"i2="+i2);
		
		durata=rute.get(i2).getSosire().diferenta_ceas_secunde(rute.get(i2).getSosire(),rute.get(i1).getPlecare());
		timer.schedule(new RemindTask(),durata*1000);
		System.out.println("loc deblocat");	
	}
	
	
	/**
	 * 
	 *deblocheaza locul ocupat dupa o perioada de timp stabilita anterior
	 *
	 */
	class RemindTask extends TimerTask {
	    public void run() {
	    System.out.println("Time's up!");
	    locuri.set(nr_loc-1,true);
	     System.exit(0); //Stops the AWT thread (and everything else)
	    }
	
	}
	
	/**
	 * returneaza numarul locului calatorului
	 * @return numarul locului
	 */
	int getNrLoc(){
		return nr_loc;
	}
	
	/**
	 * functie care returneaza situatia locurilor dintr un tren
	 * @return situatia locurilor
	 */
	public ArrayList<Boolean> getLocuri(){
		return locuri;
	}
}
