package institutie;

import java.io.Serializable;
/**
 * clasa Ruta defineste toate detaliile corespunzatoare unei rute
 * @author Moldovan Ancuta
 *
 */

public class Ruta  implements Serializable{
	
	private String nume_ruta;
	private Ceas timp_sosire;
	private double pret;
	private Ceas stationare;
/**
 * 	constructor de initializare
 * @param nume_ruta - numele rutei
 * @param pret - pretul pana la statia urmatoare
 * @param timp_sosire - ora sosirii in statie
 * @param stationare - durata stationarii
 */
	public Ruta(String nume_ruta,double pret,Ceas timp_sosire,Ceas stationare){
		this.nume_ruta=nume_ruta;
		this.pret=pret;
		this.timp_sosire=timp_sosire;
		this.stationare=stationare;
	}
	
	/**
	 * functie care returneaza numele rutei
	 * @return numele rutei
	 */
	public String getNumeRuta(){
		return nume_ruta;
	}
	
	/**
	 * functie care returneaza pretul biletului pana la statia urmatoare
	 * @return pretul pana la statia urmatoare
	 */
	public double getPret(){
		return pret;
	}
	/**
	 * functie care returneaza ora sosirii trenului repsectiv intr o statie
	 * @return ora sosirii intr o statie
	 */
	public Ceas getSosire(){//cand ajunge intr-o statie
		return timp_sosire;
	}
	/**
	 * functie care returneaza ora plecarii dintr o statie
	 * @return ora plecarii din statie
	 */
	public Ceas getPlecare(){// cand pleaca din statia respectiva dupa ce a stationat
		int h=timp_sosire.nr_ore()+stationare.nr_ore();
		int m=timp_sosire.nr_min()+stationare.nr_min();
		int s=timp_sosire.nr_sec()+stationare.nr_sec();
		
		return new Ceas(h,m,s);
	}
	/**
	 * functie care returneaza durata stationarii trenului intr o statie
	 * @return durata stationarii intr o statie
	 */
	public Ceas getStationare(){//cat timp sta intr-o statie
		return stationare;
	}
	
	
	/**
	 * functie care retunreaza toate detaliile referitoare la ruta unui tren
	 * @return sir ce contine detaliile despre o ruta
	 */
	public String veziDetalii(){
		return nume_ruta+" "+getPlecare().ceas_string()+" "+getSosire().ceas_string()+" "+stationare+" "+pret;
	}
}
