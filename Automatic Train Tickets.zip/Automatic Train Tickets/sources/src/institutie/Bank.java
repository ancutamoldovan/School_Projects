package institutie;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.TreeMap;
/**
 * clasa care contine Banca propriu-zisa si operatiile care se pot efectua intr o banca
 * @author Moldovan Ancuta
 *
 */

public class Bank implements Serializable, Institutie{
	
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	public static Hashtable<String,ArrayList<Account>> accounts=new Hashtable<String,ArrayList<Account>>();
	
	/**
	 * constructor de initializare
	 */
	
	
	
private static Bank instance=null; 
	
	private Bank(){}
	
	public static Bank getInstance() {
		if (instance == null)
			instance =new Bank();
		return instance;
	}
	
	/**
	 * adauga un cont unui client al bancii
	 * @param cnp - cnp ul clientului caruia i se adauga contul
	 * @param account - contul care se adauga
	 * @pre true
	 * @post @nochange
	 */
	public void addAccount(String cnp, Account account)
	{
		//adaugare cont in Hashtable
		
		ArrayList<Account> values = accounts.get(cnp);
		if (values == null) {
			values = new ArrayList<Account>();
		}
		if (!values.contains(account)) {
			values.add(account);
			accounts.put(cnp, values);
		}
		
		salvare();
		
		
	}
	
	/**
	 * sterge contul unui client al bancii
	 * @param cnp - cnp-ul clientului caruia i se sterge contul
	 * @param account - contul care se sterge
	 * @pre accounts != null && accounts.get(cnp) != null && accounts.get(cnp).contains(account)
	 * @post accounts!=null && accounts.get(cnp) !=null && !accounts.get(cnp).contains(account)
	 */
	public void removeAccount(String cnp,Account account){
		
		assert (accounts != null && accounts.get(cnp) != null && accounts.get(cnp).contains(account));
		//se sterge contul respectiv din hastable
		accounts.get(cnp).remove(account);
		//se sterge contul respectiv din fisier
		
		assert accounts!=null && accounts.get(cnp) !=null && !accounts.get(cnp).contains(account);
		
	}
	
	
	
	public String listToString(String key){
		assert key!=null;
		String s="";
		Iterator i=accounts.get(key).iterator();
		
		while(i.hasNext()){
			s=s+i.next().toString();
		}
		return s;
	}
	
	/**
	 * returneaza un ArrayList ce contine conturile unui client
	 * @param key - cnp ul unui client
	 * @pre key!=null
	 * @post @nochange
	 * @return - un ArrayList ce contine conturile unui client
	 */
	public ArrayList getValues(String key){
		assert key!=null;
		return accounts.get(key);
	}
	
	/**
	 * returneaza o enumerare care contine cnp urile clientilor bancii
	 * @pre accounts!=null
	 * @post @nochange
	 * @return o enumerare care contine cnp urile clientilor bancii
	 */
	public Enumeration getKeys(){
		assert	accounts!=null;
		return accounts.keys();
	}

	
	
	/**
	 * sterge un client al bancii,impreuna cu extrasul de cont al acestuia si fisierul cu conturi al acestuia
	 * @param client - clientul care se va sterge
	 * @param filename - fisierul din care se va sterge clientul
	 * @pre accounts!=null && filename!=""
	 * @post accounts!=null
	 */
	public void removeClient(Person client, String filename) {
		
		assert accounts!=null && filename!="";
		assert isWellFormed();
		//stergem clientul din hashtable
		accounts.remove(client.getCnp());
		//stergem clientul din fisier

		//stergem fisierul cu conturile acestuia
		boolean success = (new File(client.getCnp()+".txt")).delete();
		if (!success) {
		    System.out.println("Deletion failed");
		}
		//stergem fisierul care contine extrasul de cont al clientului
		boolean success2 = (new File("extras_"+client.getCnp()+".txt")).delete();
		if (!success2) {
		    System.out.println("Deletion 2 failed");
		}
		
		assert accounts!=null;
		
	}
		/**
	 * cauta un cont in intreaga structura a bancii, si returneaza contul complet, cu toate detliile acestuia
	 * @param cont - numarul contului care se cauta in intreaga banca
	 * @return - un obiect de tip Account , care reprezinta contul complet
	 * @pre cont !="" && accounts.size()>0
	 * @post @nochange
	 */
	
	public  Account cautaNrCont(String cont){
		
		assert cont !="" && accounts.size()>0;
		Enumeration en = (Enumeration) accounts.keys();
				
		while(en.hasMoreElements()){
			String key = (String) en.nextElement();
			ArrayList<Account> lista=getValues(key);
			Account[] conturi=new Account[lista.size()];
			for(int i=0;i<conturi.length;i++){
				conturi[i]=lista.get(i);
				if (conturi[i].getNr().equals(cont)) return conturi[i];
		
			}
		}
			
			
		return null;
		 
		
	}
	
	/**
	 * @invariant isWellFormed()
	 * @return boolean
	 */
	
	public boolean isWellFormed(){
		
		Enumeration en = (Enumeration) accounts.keys();
		int n=0;
		while (en.hasMoreElements()){
			n++;
		}
		
		return n==accounts.size();

	}
	
	/**
	 * salveaza continutul obiectului de tip Banca in fisierul banca.bin
	 */
	
	
	public void salvare() {
		
		try { 
			
			FileOutputStream fos = new FileOutputStream("banca.bin"); 
			ObjectOutputStream oos = new ObjectOutputStream(fos); 
			oos.writeObject(accounts); 
			oos.flush(); 
			oos.close(); 
			} 
			catch(Exception e) { 
			System.out.println("Exception during serialization: " + e); 
			System.exit(0); 
			} 
		
		
	}
	
	/**
	 * incarca obiectul de tip Banca cu informatiile preluate din fisierul banca.bin
	 */
		
		public void incarcare() {
			
			
			try { 
			
				FileInputStream fis = new FileInputStream("banca.bin"); 
				ObjectInputStream ois = new ObjectInputStream(fis); 
				accounts =(Hashtable<String, ArrayList<Account>>) ois.readObject(); 
				ois.close();
				
				} 
				catch(Exception e) { 
				System.out.println("Exception during deserialization: " + e.getMessage()); 
				System.exit(0); 
				} 
		
			
		}
	
	
	
	
	
	}


