package controller;

import institutie.Ceas;
import institutie.Interval;
import institutie.Tren;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import test.Test;
import view.Cautare;
import view.Cumparare;
/**
 * clasa care se ocupa cu toate evenimentele legate de apasarea butoanelor ale clasei Cautare
 * @author Moldovan Ancuta
 *
 */
public class CautareClick implements MouseListener {
	
	private String b;
	/**
	 * constructor care primeste prinr-un parametru informatii referitoare la cine a declansat evenimentul
	 * @param b
	 */
	public CautareClick(String b){
		this.b=b;
	}

	@Override
	/**
	 *  Metoda care executa diferite actiuni stabilite in functie de cel care a declansat evenimentul
	 */
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
		if (b=="cauta")
			{
			System.out.println(ClientClick.d.getPlecare());
			System.out.println(ClientClick.d.getDestinatie());
			
			System.out.println(ClientClick.d.combo[0].getSelectedItem()+":00");
			System.out.println(ClientClick.d.combo[1].getSelectedItem()+":00");
			System.out.println(ClientClick.d.combo[2].getSelectedItem()+":00");
			System.out.println(ClientClick.d.combo[3].getSelectedItem()+":00");
			
			
			System.out.println(((Tren) (Test.tren)).cautaTrenuri(ClientClick.d.getPlecare(),ClientClick.d.getDestinatie(),new Interval(new Ceas(ClientClick.d.combo[0].getSelectedItem()+":00"), new Ceas(ClientClick.d.combo[1].getSelectedItem()+":00")),new Interval(new Ceas(ClientClick.d.combo[2].getSelectedItem()+":00"), new Ceas(ClientClick.d.combo[3].getSelectedItem()+":00"))));
			String rezultat=((Tren) (Test.tren)).cautaTrenuri(ClientClick.d.getPlecare(),ClientClick.d.getDestinatie(),new Interval(new Ceas(ClientClick.d.combo[0].getSelectedItem()+":00"), new Ceas(ClientClick.d.combo[1].getSelectedItem()+":00")),new Interval(new Ceas(ClientClick.d.combo[2].getSelectedItem()+":00"), new Ceas(ClientClick.d.combo[3].getSelectedItem()+":00")));
			
			
			System.out.println("hey: "+rezultat);
			if (rezultat==null)
			ClientClick.d.setTextArea("Nu s-a gasit nici un tren");
		else 
			
			ClientClick.d.setTextArea(rezultat);
			System.out.println("cauta");
			}
		if (b=="cumpara")
			{
			System.out.println("cumpara");
			new Cumparare();
			}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
