package controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import view.Cautare;
import view.Cumparare;
/**
 * clasa care se ocupa cu toate evenimentele legate de apasarea butoanelor ale clasei Client
 * @author Moldovan Ancuta
 *
 */
public class ClientClick implements MouseListener {
	
	private String b;
	public static Cumparare c;
	public static Cautare d;
	
	/**
	 * constructor care primeste prinr-un parametru informatii referitoare la cine a declansat evenimentul
	 * @param b 
	 */
	public ClientClick(String b){
		this.b=b;
	}

	@Override
	/**
	 *  Metoda care executa diferite actiuni stabilite in functie de cel care a declansat evenimentul
	 */
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (b=="cauta"){
			System.out.println("cauta");
			d=new Cautare();
		}
		if (b=="cumpara"){
			System.out.println("cumparare");
			c=new Cumparare();
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
