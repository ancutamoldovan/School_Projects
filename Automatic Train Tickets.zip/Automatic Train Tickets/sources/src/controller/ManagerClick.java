package controller;

import institutie.Tren;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import test.Test;
import view.Manager;


/**
 * clasa care se ocupa cu toate evenimentele legate de apasarea butoanelor ale clasei Manager
 * @author Moldovan Ancuta
 *
 */
public class ManagerClick implements MouseListener {

	private int i;
	
	
	/**
	 * constructor care primeste prinr-un parametru informatii referitoare la cine a declansat evenimentul
	 * @param b 
	 */
	
	public ManagerClick(int i){
		this.i=i;
		
		
	}
	
	
	@Override
	/**
	 *  Metoda care executa diferite actiuni stabilite in functie de cel care a declansat evenimentul
	 */
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
		if (i==0){
			
			System.out.println("adauga ruta");
			Manager.adaugaRuta();
			
		}
			if(i==1){
				System.out.println("sterge ruta");
				Manager.stergeRuta();
				
			}
				if(i==2){
					System.out.println("sterge tren");
					Manager.stergeTren();
				}
		
		if (i==3){
			System.out.println("adaugaaa");
			((Tren) Test.tren).adaugaRuta(GuiClick.m.getNrTren(),GuiClick.m.getnrLocuri(),GuiClick.m.getRuta());
			GuiClick.c.setTextArea();
		}
			
		if (i==4)
			{
			System.out.println("stergeeeeeee ruta");
			((Tren) Test.tren).stergeRuta(GuiClick.m.getNrTren(),GuiClick.m.getRuta());
			GuiClick.c.setTextArea();
			}
		if (i==5)
			{
			System.out.println("stergeeeeeeeeee tren");
			((Tren) Test.tren).stergeTren(GuiClick.m.getNrTren());
			GuiClick.c.setTextArea();
			}
		
			
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
