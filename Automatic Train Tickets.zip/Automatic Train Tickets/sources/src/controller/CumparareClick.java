package controller;

import institutie.CumparaBilet;

/**
 * clasa care se ocupa cu toate evenimentele legate de apasarea butoanelor ale clasei Client
 * @author Moldovan Ancuta
 *
 */

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import test.Test;
import view.Cumparare;

public class CumparareClick implements MouseListener{

	
	@Override
	/**
	 *  Metoda care executa diferite actiuni stabilite in functie de cel care a declansat evenimentul
	 */
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
			
		System.out.println(ClientClick.c.getNrCont());
		System.out.println(ClientClick.c.getNrLegitimatie());
		System.out.println(ClientClick.c.getNrTren());
		
			
			new CumparaBilet(Test.bank,ClientClick.c.getNrCont(),ClientClick.c.getNrLegitimatie(), Test.tren, ClientClick.c.getNrTren(), ClientClick.c.getPlecare(), ClientClick.c.getDestinatie(), Cumparare.combo[1].getSelectedIndex(), Cumparare.combo[0].getSelectedIndex());
			ClientClick.c.citesteFisier();
			System.out.println("cumpara biletul");
			System.out.println(Cumparare.combo[0].getSelectedItem());
			System.out.println(Cumparare.combo[1].getSelectedItem());
			
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
