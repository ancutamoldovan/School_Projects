package controller;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import test.Test;
import view.Client;
import view.Manager;


/**
 * clasa care se ocupa cu toate evenimentele legate de apasarea butoanelor ale clasei GUI
 * @author Moldovan Ancuta
 *
 */
public class GuiClick implements MouseListener{
	private String b;
	public static Manager m;
	public static Client c;
	
	/**
	 * constructor care primeste prinr-un parametru informatii referitoare la cine a declansat evenimentul
	 * @param b 
	 */
	
	public GuiClick(String b){
		this.b=b;
	}

	@Override
	/**
	 *  Metoda care executa diferite actiuni stabilite in functie de cel care a declansat evenimentul
	 */
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		if (Test.gui.radio[0].isSelected()==true){
			System.out.println("Manager");
			m=new Manager();
		}
		else{
			System.out.println("Client");
			c=new Client();
		}
			
		
			
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
