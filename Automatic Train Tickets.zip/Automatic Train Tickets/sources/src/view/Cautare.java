package view;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import controller.CautareClick;

/**
 * interfata pentru cautarea unei anumite rute
 * @author Moldovan Ancuta
 *
 */
public class Cautare extends JFrame{
	
	
	JPanel panel1=new JPanel();
	JPanel panel2=new JPanel();
	JLabel destinatie,plecare,interval_sosire,interval_plecare;
	JTextField Plecare,Destinatie;
	JButton rezerva;
	JTextArea textArea=new JTextArea();
	JScrollPane scrollPane;
	public static JComboBox[] combo=new JComboBox[4];
	JButton cauta=new JButton("Cautare");
	JButton cumpara=new JButton("Cumpara");
	/**
	 * constructor de intializare
	 */
	public Cautare(){
		
		this.setLayout(new GridLayout(1, 2));
		this.add(createPanel());
		this.add(createPanel2());
		
	
		this.setTitle("Cautare");

		this.pack();
		this.setSize(600,400);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
	}
	
	/**
	 * functie care returneaza un panou care va contine rezultatele referitoare la cautare
	 * @return un panou pentru rezultatele cautarii
	 */
	public JPanel createPanel(){
		
		textArea.setEditable(false);
		scrollPane=new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(200,300));
		scrollPane.setBorder(new TitledBorder(new EtchedBorder(),"Rezultate cautare"));
		
		
		panel1.add(scrollPane);
		
		return panel1;
	}
	/**
	 * functie care returneaza un panou care contine campuri pentru cautarea unor rute
	 * @return un panou destinat cautarii rutelor
	 */
	public JPanel createPanel2(){
		
		plecare=new JLabel("Plecare");
		destinatie=new JLabel("Destinatie");
		Plecare=new JTextField(17);
		Destinatie=new JTextField(16);
		interval_plecare=new JLabel("Interval plecare");
		interval_sosire=new JLabel("Interval sosire");
	
		
		panel2.add(plecare);
		panel2.add(Plecare);
		panel2.add(destinatie);
		panel2.add(Destinatie);
		panel2.add(interval_plecare);
		creareCombo();
		panel2.add(combo[0]);
		panel2.add(combo[1]);
		
		panel2.add(interval_sosire);
		
		panel2.add(combo[2]);
		panel2.add(combo[3]);
		
		
		panel2.add(cauta);
		panel2.add(cumpara);
		
		cauta.addMouseListener(new CautareClick("cauta"));
		cumpara.addMouseListener(new CautareClick("cumpara"));
		
		return panel2;
	}
	/**
	 * functie care creaza intervalele de timp intre care clientul sa caute si anume
	 * intervalul de sosire si intervalul de plecare
	 */
	public void creareCombo(){
		
		
		String x="";
		String z="";
		int nr=23;
		
		for(int i=0;i<4;i++)
			combo[i]=new JComboBox();
		
		combo[1].addItem("23:59");
		combo[3].addItem("23:59");
		
		for(int i=0;i<=23;i++){
			if (i<10)
			x=0+""+i+":";
			else x=i+":";
			
			if (nr<10)
				z=0+""+nr+":";
				else z=nr+":";
			
		
		
			combo[0].addItem(x+"00");
			combo[2].addItem(x+"00");
			combo[1].addItem(z+"30");
			combo[3].addItem(z+"30");
			
		
			combo[0].addItem(x+"30");
			combo[2].addItem(x+"30");
			combo[1].addItem(z+"00");
			combo[3].addItem(z+"00");
					
			nr--;
		}
		
		combo[0].addItem("23:59");
		combo[2].addItem("23:59");
		
	
	
	}
	/**
	 * functie care returneaza valoarea aflata in campul Plecare
	 * @return statia din care se pleaca
	 */
	public String getPlecare(){
		return Plecare.getText();
	}
	/**
	 * functie care returneaza valoarea aflata in campul Destinatie
	 * @return statia in care se doreste sa se ajunga
	 */
	public String getDestinatie(){
		return Destinatie.getText();
	}
	/**
	 * functie care seteaza un text dat ca si parametru unui textArea
	 * @param string - textul care se scrie in textArea
	 */
	public void setTextArea(String string){
		
		textArea.setText(string);
		
		
		
	}
	
	

}
