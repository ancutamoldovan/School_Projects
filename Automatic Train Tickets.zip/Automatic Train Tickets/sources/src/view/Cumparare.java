package view;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import controller.CumparareClick;

/**
 * interfata pentru cumpararea unui bilet
 * @author Moldovan Ancuta
 *
 */
public class Cumparare extends JFrame {
	
	JPanel panel1=new JPanel();
	JPanel panel2=new JPanel();
	JLabel nr_cont,nr_legitimatie,plecare,destinatie,tip_bilet,tip_pret,nr_tren,optiune_pret,optiune_bilet;
	JTextField Nr_cont,Plecare,Destinatie,Nr_tren,Nr_legitimatie;
	public static JComboBox[] combo=new JComboBox[2];
	JTextArea textArea=new JTextArea();
	JScrollPane scrollPane;
	JButton cumpara=new JButton("Cumpara");
	
	/**
	 * constructor de initializare
	 */
	public Cumparare(){
		
		this.setLayout(new GridLayout(1, 2));
		this.add(createPanel());
		this.add(createPanel2());
		
	
		this.setTitle("Cumparare");

		this.pack();
		this.setSize(600,400);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
	}
	
	/**
	 * functie care returneaza un panou care contine starea biletelor emise
	 * @return un panou cu starea biletelor emise
	 */
	public JPanel createPanel(){
		
	textArea.setEditable(false);
	textArea.setText("Momentan nu s-a emis nici un bilet");
	scrollPane=new JScrollPane(textArea);
	scrollPane.setPreferredSize(new Dimension(200,300));
	scrollPane.setBorder(new TitledBorder("Stare bilete emise"));
	
	
	panel1.add(scrollPane);
	
	return panel1;
}
/**
 * functie care returneaza un panou care contine campurile necesare pentru cumpararea unui bilet
 * @return panou cu campurile necesare cumpararii unui bilet
 */
public JPanel createPanel2(){
	
	plecare=new JLabel("Plecare");
	destinatie=new JLabel("Destinatie");
	Plecare=new JTextField(17);
	Destinatie=new JTextField(16);
	nr_cont=new JLabel("Numar cont");
	Nr_cont=new JTextField(15);
	nr_tren=new JLabel("Numar tren");
	Nr_tren=new JTextField(16);
	nr_legitimatie=new JLabel("Numar legitimatie");
	Nr_legitimatie=new JTextField(15);
	optiune_bilet=new JLabel("Optiune bilet                      ");//dus,dus-intors
	optiune_pret=new JLabel("Optiune pret                      ");//intreg,reducere
	

	panel2.add(nr_cont);
	panel2.add(Nr_cont);
	panel2.add(nr_tren);
	panel2.add(Nr_tren);
	panel2.add(nr_legitimatie);
	panel2.add(Nr_legitimatie);
	panel2.add(plecare);
	panel2.add(Plecare);
	panel2.add(destinatie);
	panel2.add(Destinatie);
	
	creareCombo();
	panel2.add(optiune_bilet);
	panel2.add(combo[0]);
	panel2.add(optiune_pret);
	panel2.add(combo[1]);
	
	panel2.add(cumpara);
	
	cumpara.addMouseListener(new CumparareClick());
	return panel2;
}
/**
 * creaza optiunile pentru bilete
 * bilet dus sau bilet dus intors
 * bilet intreg sau bilet reducere
 */
	public void creareCombo(){
	String[] opt1={"Bilet dus","Bilet dus-intors"};
	String[] opt2={"Bilet intreg","Bilet Reducere"};
	
	combo[0]=new JComboBox(opt1);
	combo[1]=new JComboBox(opt2);
	
	
	}

	/**
	 * functie care returneaza numarul contului tastat de client
	 * @return numarul contului
	 */
	public String getNrCont(){
		return Nr_cont.getText();
	}
	
	/**
	 * functie care returneaza numarul legitimatie tastat de client
	 * @return numarul legitimatiei
	 */
	public String getNrLegitimatie(){
		return Nr_legitimatie.getText();
	}
	
	public String getNrTren(){
		return Nr_tren.getText();
	}
	
	public String getPlecare(){
		return Plecare.getText();
	}
	
	public String getDestinatie(){
		return Destinatie.getText();
	}
	/**
	 * functie care citeste fisierul care contine biletul emis calatorului
	 */
	public void citesteFisier(){

		textArea.setText("");
		BufferedReader br=null;
	    try {
	    	br=new BufferedReader(new FileReader("bilet.txt"));
	        textArea.read(br, null);
	        br.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    
	    
	}


}
