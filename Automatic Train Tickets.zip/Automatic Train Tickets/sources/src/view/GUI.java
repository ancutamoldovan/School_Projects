package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import controller.GuiClick;

/**
 * interfata care apare in momentul in care se lanseaza aplicatia
 * @author Moldovan Ancuta
 *
 */
public class GUI extends JFrame {

	
	JPanel panel1=new JPanel();
	JPanel panel2=new JPanel();
	JLabel label = new JLabel("Alege");
	JComboBox comboBox = new JComboBox();
	JButton start = new JButton ("Start");
	ButtonGroup group = new ButtonGroup(); 
	
	public static JRadioButton[] radio=new JRadioButton[2];
	
	/**
	 * constructor de initializare
	 */
	public GUI(){

		this.setLayout(new GridLayout(2,1));
		this.add(createPanel());
		this.add(createPanel2());

		this.pack();
		this.setSize(500,300);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * functie care returneaza un panou care contine logo-ul CFR ului
	 * @return un panou cu logo CFR
	 */
	
	public JPanel createPanel(){
		
		
		BufferedImage myPicture;
		try {
			myPicture = ImageIO.read(new File("logo.jpg"));
			JLabel picLabel = new JLabel(new ImageIcon( myPicture ));
			panel1.add( picLabel );

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return panel1;
	}
	
	/**
	 * un panou care contine cele 2 optiuni puse la dipozitie:manager si client
	 * @return panou cu optiuni
	 */
	public JPanel createPanel2(){
		
		panel2.add(label);
		
		radio[0]=new JRadioButton("Manager");
		radio[1]=new JRadioButton("Client");
		
		group.add(radio[0]);
		group.add(radio[1]);
		
		
		
		panel2.add(radio[0]);
		panel2.add(radio[1]);
		panel2.add(start);
		setFunctie();
		return panel2;
	}
	
	/**
	 * functie care seteaza butonului start un listener
	 */
	
	public void setFunctie(){
		

		start.addMouseListener(new GuiClick("start"));
	
	}




}
