package view;
import institutie.Ceas;
import institutie.Ruta;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.ManagerClick;

/**
 * interfata pentru manager
 * @author Moldovan Ancuta
 *
 */

public class Manager extends JFrame {
	
	static JPanel panel1=new JPanel();
	JPanel panel2=new JPanel();
	JLabel alege;
	JComboBox[] combo=new JComboBox[2];
	static JLabel nr_tren;
	static JLabel nr_locuri;
	static JLabel statie;
	static JLabel pret;
	static JLabel timp_sosire;
	static JLabel timp_stationare;
	static JTextField Nr_tren,Nr_locuri,Statie,Pret;
	static JTextField Timp_sosire;
	static JTextField Timp_stationare;
	JRadioButton[] radio =new JRadioButton[3];
	ButtonGroup group = new ButtonGroup(); 
	static JButton adauga;
	static JButton sterge_ruta;
	static JButton sterge_tren;
	/**
	 * constructor de initializare
	 */
	public Manager(){
		
		this.setLayout(new GridLayout(1, 2));
		this.add(createPanel());
		this.add(createPanel2());
		
	
		this.setTitle("Manager");

		this.pack();
		this.setSize(600,400);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
	}

	
	/**
	 * functie care returneaza un panou ce va contine campuri necesare introducerii/stergerii de informatii
	 * @return panou cu campuri
	 */
	public JPanel  createPanel(){
		
		return panel1;
		
		
	}
	
	/**
	 * functie care returneaza un panou care contine optiunile puse la dispozitia managerului
	 * @return panou cu optiuni
	 */
	public JPanel createPanel2(){
		
		panel2.setLayout(new GridLayout(4,1));
		alege=new JLabel("Alege");
		
		creareRadio();
		
		group.add(radio[0]);
		group.add(radio[1]);
		group.add(radio[2]);
		
		panel2.add(alege);
		panel2.add(radio[0]);
		panel2.add(radio[1]);
		panel2.add(radio[2]);
		
		return panel2;
	}
	
	/**
	 * functie care creaza optiunile pentru manager
	 */
	public void creareRadio(){
		radio[0]=new JRadioButton("Adauga ruta");
		radio[1]=new JRadioButton("Sterge ruta");
		radio[2]=new JRadioButton("Sterge tren");
		
		radio[0].addMouseListener(new ManagerClick(0));
		radio[1].addMouseListener(new ManagerClick(1));
		radio[2].addMouseListener(new ManagerClick(2));
		
	}
	
	/**
	 * functie care completeaza panoul pentru campuri cu campurile necesare
	 */
	
	public static void popularePanel1(){
		
		nr_tren=new JLabel("Numar tren");
		Nr_tren=new JTextField(15);
		nr_locuri=new JLabel("Numar locuri");
		Nr_locuri=new JTextField(18);
		statie=new JLabel("Statie");
		Statie=new JTextField(20);
		pret=new JLabel("Pret");
		Pret=new JTextField(20);
		timp_sosire=new JLabel("Ora sosire");
		Timp_sosire=new JTextField(15);
		timp_stationare=new JLabel("Timp stationare");
		Timp_stationare=new JTextField(10);
		adauga=new JButton("Adauga ruta");
		sterge_ruta=new JButton("Sterge ruta");
		sterge_tren=new JButton("Sterge tren");
		panel1.add(nr_tren);
		panel1.add(Nr_tren);
		panel1.add(nr_locuri);
		panel1.add(Nr_locuri);
		panel1.add(statie);
		panel1.add(Statie);
		panel1.add(pret);
		panel1.add(Pret);
		panel1.add(timp_sosire);
		panel1.add(Timp_sosire);
		panel1.add(timp_stationare);
		panel1.add(Timp_stationare);
		panel1.add(adauga);
		panel1.add(sterge_ruta);
		panel1.add(sterge_tren);
		//return panel;
		
		adauga.addMouseListener(new ManagerClick(3));
		sterge_ruta.addMouseListener(new ManagerClick(4));
		sterge_tren.addMouseListener(new ManagerClick(5));
		
		
		
		panel1.revalidate();
	}
	
	/**
	 * campurile necesare pentru adaugarea unei rute
	 */
	public static void adaugaRuta(){
		refreshPanel1();
		popularePanel1();
		sterge_ruta.setEnabled(false);
		sterge_tren.setEnabled(false);
	}
	
	/**
	 * campurile necesare pentru stergerea unei rute
	 */
	public static void stergeRuta(){
		
		refreshPanel1();
		popularePanel1();
		adauga.setEnabled(false);
		sterge_tren.setEnabled(false);
		Nr_locuri.setEnabled(false);
	}
	
	/**
	 * campurile necesare pentru stergerea unui tren
	 */
	
	public static void stergeTren(){
		refreshPanel1();
		popularePanel1();
		
		adauga.setEnabled(false);
		sterge_ruta.setEnabled(false);
		Nr_locuri.setEnabled(false);
		Statie.setEnabled(false);
		Pret.setEnabled(false);
		Timp_stationare.setEnabled(false);
		Timp_sosire.setEnabled(false);
	}
	
	
	/**
	 * metoada pentru  stergerea tuturor campurilor create
	 */
	public static void refreshPanel1(){
		panel1.removeAll();
		panel1.revalidate();
		panel1.repaint();
	}
	/**
	 * functie care returneaza un obiect de tip Ruta 
	 */
	public Ruta getRuta(){
		return new Ruta(Statie.getText(),Double.parseDouble(Pret.getText()),new Ceas(Timp_sosire.getText()),new Ceas(Timp_stationare.getText()));
	}
	
	/**
	 * functie care returneaza numarul trenului pe care dorim sa l adaugam/stergem
	 * @return numarul trenului
	 */
	public String getNrTren(){
		return Nr_tren.getText();
	}
	/**
	 * functie care returneaza numarul de locuri dintr un tren
	 * @return numarul de locuri
	 */
	public int getnrLocuri(){
		return Integer.parseInt(Nr_locuri.getText());
	}
	
		
}
