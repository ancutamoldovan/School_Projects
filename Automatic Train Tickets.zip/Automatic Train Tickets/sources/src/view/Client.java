package view;

import institutie.Tren;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import test.Test;

import controller.ClientClick;


/**
 * interfata pusa la dispozitie clientului
 * @author Moldovan Ancuta
 *
 */
public class Client extends JFrame{
	
	
	JPanel panel=new JPanel();

	JTextArea textArea=new JTextArea();
	JScrollPane scrollPane;
	JButton cauta=new JButton("Cauta");
	JButton cumpara=new JButton("Cumpara");
	/**
	 * constructor de intializare
	 */
	public Client(){
		this.add(createPanel());
		
		
		this.setTitle("Client");

		this.pack();
		this.setSize(600,400);
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
	}
	/**
	 * functie care  un panou care contine elementele vizuale puse la dipozitia clientului
	 * @return un panou care contine elementele vizuale 
	 */
	public JPanel createPanel(){
		textArea.setEditable(false);
		scrollPane=new JScrollPane(textArea);
		textArea.setForeground(Color.black);
		textArea.setFont(new Font("TimesNewRoman", Font.LAYOUT_LEFT_TO_RIGHT, 16));
		
		setTextArea();
		scrollPane.setPreferredSize(new Dimension(300,350));
		panel.add(scrollPane);
		panel.add(cauta);
		panel.add(cumpara);
		
		cauta.addMouseListener(new ClientClick("cauta"));
		cumpara.addMouseListener(new ClientClick("cumpara"));
		
		return panel;
	}
	

	/**
	 * seteaza in textArea toate trenurile
	 */
	public void setTextArea(){
		textArea.setText("\tInformatii trenuri\t\n");
		textArea.append(((Tren) Test.tren).veziTrenuri());
		
		
	}
	
	

}
