package test;

import institutie.Institutie;
import institutie.InstitutieFactory;
import view.GUI;
/**
 * clasa principala din care se lanseaza aplicatia
 * @author Moldovan Ancuta
 *
 */
public class Test {
	
	public static Institutie bank=InstitutieFactory.getInstitutie("banca");
	public static Institutie tren=InstitutieFactory.getInstitutie("gara");
	public static GUI gui=new GUI();
/**
 * metoda care pune in functiunea aplicatia
 * @param args
 */
	public static void main(String[] args){
		bank.incarcare();
		tren.incarcare();
		
	}
}
